// ── AGENT-OWNED: admin data-access ────────────────────────────────────────────
// Everything the dashboard reads and writes. Kept apart from db.ts (the mining
// engine) so the engine stays small and the admin surface is auditable in one
// place. Every function here is reachable ONLY through adminProcedure.
import { and, count, desc, eq, gte, sql } from "drizzle-orm";
import { hash as bcryptHash, compare as bcryptCompare } from "bcryptjs";
import { atomic, db } from "./_core/db";
import { adminTasks, ledger, miningSessions, profiles, referrals, siteSettings, users } from "../drizzle/schema";
import { accrualFor, round6 } from "../shared/mining";
import {
  settingsToRows,
  type AdminStats,
  type AdminTaskView,
  type AdminUserRow,
  type SiteSettings,
  type TaskKind,
} from "../shared/admin";
import { getSettings } from "./db";

export class AdminError extends Error {}

// ── settings ──────────────────────────────────────────────────────────────────

export async function saveSettings(next: SiteSettings): Promise<SiteSettings> {
  const rows = settingsToRows(next);
  const now = new Date();
  // One atomic batch: the app can never read a half-applied economy. `atomic`
  // is the platform's replacement for `db.transaction` (the http driver has no
  // interactive transactions), so every upsert leaves together.
  await atomic((d) =>
    rows.map((row) =>
      d
        .insert(siteSettings)
        .values({ key: row.key, value: row.value, updatedAt: now })
        .onConflictDoUpdate({
          target: siteSettings.key,
          set: { value: row.value, updatedAt: now },
        }),
    ) as never,
  );
  return getSettings();
}

// ── tasks & announcements ─────────────────────────────────────────────────────

function toTaskView(r: typeof adminTasks.$inferSelect): AdminTaskView {
  return {
    id: r.id,
    title: r.title,
    body: r.body,
    kind: r.kind as TaskKind,
    active: r.active,
    sortOrder: r.sortOrder,
    createdAt: r.createdAt.toISOString(),
    updatedAt: r.updatedAt.toISOString(),
  };
}

/** Every task, published or not — the dashboard's list. */
export async function listTasks(): Promise<AdminTaskView[]> {
  const rows = await db
    .select()
    .from(adminTasks)
    .orderBy(adminTasks.sortOrder, desc(adminTasks.createdAt));
  return rows.map(toTaskView);
}

/** Only what miners may see: active rows, in display order. */
export async function listPublicTasks(): Promise<AdminTaskView[]> {
  const rows = await db
    .select()
    .from(adminTasks)
    .where(eq(adminTasks.active, true))
    .orderBy(adminTasks.sortOrder, desc(adminTasks.createdAt));
  return rows.map(toTaskView);
}

export async function createTask(input: {
  title: string;
  body: string;
  kind: TaskKind;
  active: boolean;
  sortOrder: number;
}): Promise<AdminTaskView> {
  const title = input.title.trim();
  if (!title) throw new AdminError("A task needs a title.");
  const [row] = await db
    .insert(adminTasks)
    .values({
      title,
      body: input.body.trim(),
      kind: input.kind,
      active: input.active,
      sortOrder: input.sortOrder,
    })
    .returning();
  return toTaskView(row);
}

export async function updateTask(
  id: string,
  patch: Partial<{ title: string; body: string; kind: TaskKind; active: boolean; sortOrder: number }>,
): Promise<AdminTaskView> {
  const set: Record<string, unknown> = { updatedAt: new Date() };
  if (patch.title !== undefined) {
    const t = patch.title.trim();
    if (!t) throw new AdminError("A task needs a title.");
    set.title = t;
  }
  if (patch.body !== undefined) set.body = patch.body.trim();
  if (patch.kind !== undefined) set.kind = patch.kind;
  if (patch.active !== undefined) set.active = patch.active;
  if (patch.sortOrder !== undefined) set.sortOrder = patch.sortOrder;

  const [row] = await db.update(adminTasks).set(set).where(eq(adminTasks.id, id)).returning();
  if (!row) throw new AdminError("That task no longer exists.");
  return toTaskView(row);
}

export async function deleteTask(id: string): Promise<{ ok: true }> {
  const [row] = await db.delete(adminTasks).where(eq(adminTasks.id, id)).returning();
  if (!row) throw new AdminError("That task no longer exists.");
  return { ok: true };
}

// ── users ─────────────────────────────────────────────────────────────────────

/**
 * Every registered account with its mining profile and circle counts. One query
 * with two correlated subqueries rather than N+1: the dashboard lists everyone,
 * so a per-row round trip would be hundreds of queries on a real network.
 */
export async function listUsers(limit = 500): Promise<AdminUserRow[]> {
  const rows = await db
    .select({
      userId: users.id,
      email: users.email,
      role: users.role,
      createdAt: users.createdAt,
      username: profiles.username,
      balance: profiles.balance,
      totalMined: profiles.totalMined,
      suspended: profiles.suspended,
      circleActive: sql<number>`(
        select count(*)::int from ${referrals}
        where ${referrals.referrerId} = ${users.id} and ${referrals.active} = true
      )`,
      circleTotal: sql<number>`(
        select count(*)::int from ${referrals}
        where ${referrals.referrerId} = ${users.id}
      )`,
    })
    .from(users)
    .leftJoin(profiles, eq(profiles.userId, users.id))
    .orderBy(desc(users.createdAt))
    .limit(limit);

  return rows.map((r) => ({
    userId: r.userId,
    email: r.email,
    username: r.username ?? "—",
    balance: r.balance ?? 0,
    totalMined: r.totalMined ?? 0,
    suspended: r.suspended ?? false,
    role: r.role,
    circleActive: r.circleActive ?? 0,
    circleTotal: r.circleTotal ?? 0,
    createdAt: r.createdAt.toISOString(),
  }));
}

export async function setUserSuspended(userId: string, suspended: boolean): Promise<{ ok: true }> {
  const [row] = await db
    .update(profiles)
    .set({ suspended })
    .where(eq(profiles.userId, userId))
    .returning();
  if (!row) throw new AdminError("That account has no mining profile yet.");
  return { ok: true };
}

// ── sessions ──────────────────────────────────────────────────────────────────

export interface AdminSessionRow {
  id: string;
  userId: string;
  username: string;
  email: string;
  startedAt: string;
  endsAt: string;
  baseRate: number;
  boostRate: number;
  /** What the session has accrued so far (or its final amount, once claimed). */
  accrued: number;
  claimed: boolean;
  claimedAt: string | null;
  /** True when the 24h window has passed but the user has not claimed yet. */
  awaitingClaim: boolean;
  /** True when the window is still open. */
  running: boolean;
}

/**
 * Every mining session, newest first, with the owner's identity and the amount
 * accrued as of now. `accrued` is recomputed from the stored timestamps and
 * rates — the same function the miner's own screen uses — so the dashboard can
 * never disagree with what the user sees.
 */
export async function listSessions(limit = 300): Promise<AdminSessionRow[]> {
  const rows = await db
    .select({
      id: miningSessions.id,
      userId: miningSessions.userId,
      startedAt: miningSessions.startedAt,
      endsAt: miningSessions.endsAt,
      baseRate: miningSessions.baseRate,
      boostRate: miningSessions.boostRate,
      minedAmount: miningSessions.minedAmount,
      claimed: miningSessions.claimed,
      claimedAt: miningSessions.claimedAt,
      username: profiles.username,
      email: users.email,
    })
    .from(miningSessions)
    .innerJoin(users, eq(users.id, miningSessions.userId))
    .leftJoin(profiles, eq(profiles.userId, miningSessions.userId))
    .orderBy(desc(miningSessions.startedAt))
    .limit(limit);

  const now = new Date();
  return rows.map((r) => {
    const accrued = r.claimed
      ? r.minedAmount
      : accrualFor({
          startedAt: r.startedAt,
          endsAt: r.endsAt,
          now,
          baseRate: r.baseRate,
          boostRate: r.boostRate,
        });
    const ended = r.endsAt.getTime() <= now.getTime();
    return {
      id: r.id,
      userId: r.userId,
      username: r.username ?? "—",
      email: r.email,
      startedAt: r.startedAt.toISOString(),
      endsAt: r.endsAt.toISOString(),
      baseRate: r.baseRate,
      boostRate: r.boostRate,
      accrued: round6(accrued),
      claimed: r.claimed,
      claimedAt: r.claimedAt ? r.claimedAt.toISOString() : null,
      awaitingClaim: !r.claimed && ended,
      running: !r.claimed && !ended,
    };
  });
}

// ── referral relationships ────────────────────────────────────────────────────

export interface AdminReferralRow {
  id: string;
  referrerUsername: string;
  refereeUsername: string;
  active: boolean;
  bonusPaid: boolean;
  createdAt: string;
}

export async function listReferrals(limit = 300): Promise<AdminReferralRow[]> {
  const rows = await db
    .select({
      id: referrals.id,
      referrerUsername: sql<string>`(
        select p.username from ${profiles} p where p.user_id = ${referrals.referrerId}
      )`,
      refereeUsername: sql<string>`(
        select p.username from ${profiles} p where p.user_id = ${referrals.refereeId}
      )`,
      active: referrals.active,
      bonusPaidAt: referrals.bonusPaidAt,
      createdAt: referrals.createdAt,
    })
    .from(referrals)
    .orderBy(desc(referrals.createdAt))
    .limit(limit);

  return rows.map((r) => ({
    id: r.id,
    referrerUsername: r.referrerUsername ?? "—",
    refereeUsername: r.refereeUsername ?? "—",
    active: r.active,
    bonusPaid: r.bonusPaidAt !== null,
    createdAt: r.createdAt.toISOString(),
  }));
}

// ── stats ─────────────────────────────────────────────────────────────────────

export async function getStats(): Promise<AdminStats> {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const [userCount] = await db.select({ n: count() }).from(users);
  const [newToday] = await db.select({ n: count() }).from(users).where(gte(users.createdAt, startOfDay));
  const [openSessions] = await db
    .select({ n: count() })
    .from(miningSessions)
    .where(eq(miningSessions.claimed, false));
  const [suspended] = await db
    .select({ n: count() })
    .from(profiles)
    .where(eq(profiles.suspended, true));
  const [activeTasks] = await db
    .select({ n: count() })
    .from(adminTasks)
    .where(eq(adminTasks.active, true));
  const [totals] = await db
    .select({
      mined: sql<number>`coalesce(sum(${profiles.totalMined}), 0)::double precision`,
      balance: sql<number>`coalesce(sum(${profiles.balance}), 0)::double precision`,
    })
    .from(profiles);

  return {
    totalUsers: Number(userCount?.n ?? 0),
    newUsersToday: Number(newToday?.n ?? 0),
    activeSessions: Number(openSessions?.n ?? 0),
    totalMined: round6(Number(totals?.mined ?? 0)),
    totalBalance: round6(Number(totals?.balance ?? 0)),
    suspendedUsers: Number(suspended?.n ?? 0),
    activeTasks: Number(activeTasks?.n ?? 0),
  };
}

// ── ledger (admin view) ───────────────────────────────────────────────────────

export interface AdminLedgerRow {
  id: string;
  username: string;
  amount: number;
  type: string;
  note: string | null;
  createdAt: string;
}

export async function listLedger(limit = 200): Promise<AdminLedgerRow[]> {
  const rows = await db
    .select({
      id: ledger.id,
      amount: ledger.amount,
      type: ledger.type,
      note: ledger.note,
      createdAt: ledger.createdAt,
      username: profiles.username,
    })
    .from(ledger)
    .leftJoin(profiles, eq(profiles.userId, ledger.userId))
    .orderBy(desc(ledger.createdAt))
    .limit(limit);

  return rows.map((r) => ({
    id: r.id,
    username: r.username ?? "—",
    amount: r.amount,
    type: r.type,
    note: r.note,
    createdAt: r.createdAt.toISOString(),
  }));
}

/** Guard used by the router: is this user id an admin? */
export async function isAdminUser(userId: string): Promise<boolean> {
  const [row] = await db.select({ role: users.role }).from(users).where(eq(users.id, userId)).limit(1);
  return row?.role === "admin";
}

/**
 * Emails listed in the ADMIN_EMAILS config value, lowercased. This is how the
 * first admin is designated without a password ever living in code or a
 * migration: the owner sets the value in Web Admin → Secrets, signs up with
 * that address, and is promoted on the spot.
 *
 * An unset value means "no allowlist" — the app still works, nobody is promoted.
 */
export async function adminEmails(): Promise<string[]> {
  try {
    // Imported lazily: _core/env validates DATABASE_URL at module load, and this
    // module is imported by the router, which the frozen test harness loads
    // without a database. Reading it here keeps that coupling out of import time.
    const { env } = await import("./_core/env");
    return env
      .config("ADMIN_EMAILS", "")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);
  } catch {
    return [];
  }
}

/**
 * Promote an account whose email is on the allowlist. Called on signup and on
 * every admin.whoami, so an owner who adds their address later is promoted the
 * next time they open the console — no re-registration, no manual SQL.
 *
 * Only ever promotes. Demotion is deliberate and stays manual, so a typo in the
 * config cannot silently lock the owner out of their own console.
 */
export async function syncAdminRole(userId: string, email: string): Promise<boolean> {
  const allow = await adminEmails();
  if (allow.length > 0 && allow.includes(email.trim().toLowerCase())) {
    const [row] = await db
      .update(users)
      .set({ role: "admin" })
      .where(and(eq(users.id, userId), eq(users.role, "user")))
      .returning();
    return Boolean(row);
  }

  // Bootstrap: on a network with no admin yet, the EARLIEST-created account is
  // the owner. This is what makes the console self-sufficient — the person who
  // set the network up signs in and has the dashboard, with no secret to
  // configure and no code change. It stops firing the moment any admin exists,
  // so it can never promote a later signup.
  const [admins] = await db
    .select({ n: count() })
    .from(users)
    .where(eq(users.role, "admin"));
  if (Number(admins?.n ?? 0) > 0) return false;

  const [first] = await db
    .select({ id: users.id })
    .from(users)
    .orderBy(users.createdAt)
    .limit(1);
  if (!first || first.id !== userId) return false;

  const [row] = await db
    .update(users)
    .set({ role: "admin" })
    .where(and(eq(users.id, userId), eq(users.role, "user")))
    .returning();
  return Boolean(row);
}

/** Promote/demote by email — the bootstrap path for the first admin. */
export async function setRoleByEmail(email: string, role: "user" | "admin"): Promise<{ ok: true }> {
  const [row] = await db
    .update(users)
    .set({ role })
    .where(eq(users.email, email.trim().toLowerCase()))
    .returning();
  if (!row) throw new AdminError("No account with that email.");
  return { ok: true };
}

export { and };

// ── admin credentials ─────────────────────────────────────────────────────────

/**
 * Change the signed-in admin's own password. Requires the current one, so a
 * hijacked session cannot silently lock the owner out of their own console.
 *
 * This is what makes the dashboard self-sufficient: the owner sets their own
 * password from the browser and never needs a code change or a new build.
 */
export async function changeOwnPassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
): Promise<{ ok: true }> {
  if (newPassword.length < 8) {
    throw new AdminError("The new password must be at least 8 characters.");
  }
  const [row] = await db
    .select({ passwordHash: users.passwordHash })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!row?.passwordHash) throw new AdminError("This account has no password set.");

  const ok = await bcryptCompare(currentPassword, row.passwordHash);
  if (!ok) throw new AdminError("That current password is not correct.");

  await db
    .update(users)
    .set({ passwordHash: await bcryptHash(newPassword, 10) })
    .where(eq(users.id, userId));
  return { ok: true };
}