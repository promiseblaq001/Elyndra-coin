// ── Mobile API ───────────────────────────────────────────────────────────────
// A small REST surface for the Elyndra Coin phone app (Expo / React Native).
//
// Why REST and not tRPC: a native app has no cookie jar it can rely on, and the
// tRPC HTTP wire format (superjson + batched GET params) is awkward to consume
// from React Native. So this module exposes plain JSON endpoints authenticated
// with a Bearer token instead of the browser session cookie.
//
// It is a THIN adapter, on purpose. Every endpoint calls the same functions the
// website calls (server/db.ts, server/daily.ts, server/admin.ts), so the phone
// app and the site can never disagree about a balance, a rate or a session —
// there is exactly one mining engine and one database behind both.
import { Hono, type Context } from "hono";
import { SignJWT, jwtVerify } from "jose";
import { eq } from "drizzle-orm";
import { db } from "./_core/db";
import { env } from "./_core/env";
import { authProvider, registerLocalUser, AuthError, EmailTakenError } from "./_core/auth";
import { users } from "../drizzle/schema";
import * as q from "./db";
import { MiningError } from "./db";
import * as daily from "./daily";
import * as admin from "./admin";
import { AdminError } from "./admin";
import { DEFAULT_SETTINGS, SETTING_LIMITS, type SiteSettings, type TaskKind } from "../shared/admin";

const secretKey = new TextEncoder().encode(env.jwtSecret);

/** How long a phone stays signed in without re-entering a password. */
const TOKEN_TTL = "30d";

async function issueToken(userId: string): Promise<string> {
  return new SignJWT({})
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setIssuedAt()
    .setExpirationTime(TOKEN_TTL)
    .sign(secretKey);
}

/** The user id behind a Bearer token, or null. Never throws. */
async function userIdFrom(c: Context): Promise<string | null> {
  const header = c.req.header("authorization") ?? "";
  const token = header.toLowerCase().startsWith("bearer ") ? header.slice(7).trim() : "";
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secretKey);
    return payload.sub ?? null;
  } catch {
    return null; // expired / tampered → anonymous
  }
}

type Authed = { id: string; email: string; name: string | null; role: string };

async function currentUser(c: Context): Promise<Authed | null> {
  const id = await userIdFrom(c);
  if (!id) return null;
  const [row] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!row) return null;
  return { id: row.id, email: row.email, name: row.name, role: row.role };
}

/** Map a domain failure to a status + message the app can show as-is. */
function fail(c: Context, e: unknown) {
  if (e instanceof EmailTakenError) return c.json({ error: e.message }, 409);
  if (e instanceof AuthError) return c.json({ error: e.message }, 401);
  if (e instanceof MiningError || e instanceof AdminError) return c.json({ error: e.message }, 400);
  // eslint-disable-next-line no-console
  console.error("[mobile-api] unhandled", e);
  return c.json({ error: "Something went wrong. Please try again." }, 500);
}

async function body<T>(c: Context): Promise<T> {
  try {
    return (await c.req.json()) as T;
  } catch {
    return {} as T;
  }
}

export const mobileApi = new Hono();

/**
 * CORS for the phone app.
 *
 * A native app does not enforce CORS, but the same code also runs as a web build
 * (Expo's web target) and in Expo Go's web preview, where the API is on a
 * different origin. Auth is a Bearer token, never a cookie, so a permissive
 * origin is safe here: there is no ambient credential a hostile page could ride.
 * `authorization` must be allowed explicitly or the preflight fails.
 */
mobileApi.use("*", async (c, next) => {
  c.header("Access-Control-Allow-Origin", "*");
  c.header("Access-Control-Allow-Methods", "GET, POST, PATCH, PUT, DELETE, OPTIONS");
  c.header("Access-Control-Allow-Headers", "authorization, content-type, accept");
  c.header("Access-Control-Max-Age", "86400");
  if (c.req.method === "OPTIONS") return c.body(null, 204);
  await next();
});

// ── auth ─────────────────────────────────────────────────────────────────────

mobileApi.post("/signup", async (c) => {
  const input = await body<{ email?: string; password?: string; name?: string; refCode?: string }>(c);
  const email = (input.email ?? "").trim().toLowerCase();
  const password = input.password ?? "";
  const name = (input.name ?? "").trim();

  // The name is compulsory here too — the phone app must not be a way around
  // the rule the website enforces.
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return c.json({ error: "Enter a valid email address." }, 400);
  if (password.length < 8) return c.json({ error: "Your password must be at least 8 characters." }, 400);
  if (name.length < 2) return c.json({ error: "Please enter your name (at least 2 characters)." }, 400);
  if (name.length > 60) return c.json({ error: "That name is too long." }, 400);

  try {
    const user = await registerLocalUser(email, password, name);
    try {
      await q.ensureProfile(user.id, input.refCode);
    } catch {
      // A profile that cannot be created yet is retried on the first status call.
    }
    try {
      await admin.syncAdminRole(user.id, user.email);
    } catch {
      // Promotion is retried on the next admin.whoami.
    }
    return c.json({ token: await issueToken(user.id), user });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/login", async (c) => {
  const input = await body<{ email?: string; password?: string }>(c);
  const email = (input.email ?? "").trim().toLowerCase();
  const password = input.password ?? "";
  if (!email || !password) return c.json({ error: "Enter your email and password." }, 400);

  try {
    // Reuse the same credential check the website uses, but without the cookie:
    // a throwaway Hono context is not needed — compare directly.
    const [row] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const { compare } = await import("bcryptjs");
    const hash = row?.passwordHash ?? "$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinv";
    const ok = await compare(password, hash);
    if (!row || !row.passwordHash || !ok) return c.json({ error: "Invalid email or password" }, 401);
    return c.json({
      token: await issueToken(row.id),
      user: { id: row.id, email: row.email, name: row.name, role: row.role },
    });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/me", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  return c.json({ user });
});

// ── mining ───────────────────────────────────────────────────────────────────

mobileApi.get("/status", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    return c.json(await q.getStatus(user.id));
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/start", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    await q.startSession(user.id);
    return c.json(await q.getStatus(user.id));
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/claim", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    const result = await q.claimSession(user.id);
    return c.json({ ...result, status: await q.getStatus(user.id) });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/team", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    return c.json(await q.getTeam(user.id));
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/ledger", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    return c.json({ entries: await q.getLedger(user.id) });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.patch("/profile", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  const input = await body<{ username?: string }>(c);
  try {
    const row = await q.setUsername(user.id, input.username ?? "");
    return c.json({ username: row.username });
  } catch (e) {
    return fail(c, e);
  }
});

/** What the admin has published to the network — public, like the website's. */
mobileApi.get("/tasks", async (c) => {
  try {
    return c.json({ tasks: await admin.listPublicTasks() });
  } catch (e) {
    return fail(c, e);
  }
});

// ── daily tasks ──────────────────────────────────────────────────────────────

mobileApi.get("/daily", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    return c.json(await daily.getDailyProgress(user.id));
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/daily/complete", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  const input = await body<{ taskId?: string }>(c);
  if (!input.taskId) return c.json({ error: "Which task?" }, 400);
  try {
    return c.json(await daily.completeDailyTask(user.id, input.taskId));
  } catch (e) {
    return fail(c, e);
  }
});

// ── admin ────────────────────────────────────────────────────────────────────
// Every route below requires a signed-in user whose role is 'admin'. A normal
// account gets 403, an anonymous caller 401 — the same rule the website's
// adminProcedure applies.

async function requireAdmin(c: Context): Promise<Authed | Response> {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    await admin.syncAdminRole(user.id, user.email);
  } catch {
    // A failed promotion must not break the gate.
  }
  const isAdmin = await admin.isAdminUser(user.id);
  if (!isAdmin) return c.json({ error: "This account is not an admin." }, 403);
  return user;
}

mobileApi.get("/admin/whoami", async (c) => {
  const user = await currentUser(c);
  if (!user) return c.json({ error: "Not signed in." }, 401);
  try {
    await admin.syncAdminRole(user.id, user.email);
  } catch {
    /* ignore */
  }
  const isAdmin = await admin.isAdminUser(user.id);
  return c.json({ isAdmin, email: user.email, role: isAdmin ? "admin" : user.role });
});

mobileApi.get("/admin/stats", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json(await admin.getStats());
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/admin/users", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json({ users: await admin.listUsers(500) });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/admin/sessions", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json({ sessions: await admin.listSessions(300) });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/admin/referrals", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json({ referrals: await admin.listReferrals(300) });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.get("/admin/ledger", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json({ entries: await admin.listLedger(200) });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/admin/users/:id/suspend", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<{ suspended?: boolean }>(c);
  const targetId = c.req.param("id");
  if (targetId === gate.id && input.suspended) {
    return c.json({ error: "You cannot suspend your own account." }, 400);
  }
  try {
    return c.json(await admin.setUserSuspended(targetId, Boolean(input.suspended)));
  } catch (e) {
    return fail(c, e);
  }
});

// ── admin: tasks & announcements ─────────────────────────────────────────────

mobileApi.get("/admin/tasks", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json({ tasks: await admin.listTasks() });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/admin/tasks", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<{
    title?: string;
    body?: string;
    kind?: TaskKind;
    active?: boolean;
    sortOrder?: number;
  }>(c);
  try {
    return c.json(
      await admin.createTask({
        title: input.title ?? "",
        body: input.body ?? "",
        kind: input.kind === "announcement" ? "announcement" : "task",
        active: input.active ?? true,
        sortOrder: input.sortOrder ?? 0,
      }),
    );
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.patch("/admin/tasks/:id", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<{
    title?: string;
    body?: string;
    kind?: TaskKind;
    active?: boolean;
    sortOrder?: number;
  }>(c);
  try {
    return c.json(await admin.updateTask(c.req.param("id"), input));
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.delete("/admin/tasks/:id", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json(await admin.deleteTask(c.req.param("id")));
  } catch (e) {
    return fail(c, e);
  }
});

// ── admin: daily tasks ───────────────────────────────────────────────────────

mobileApi.get("/admin/daily", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json({ tasks: await daily.listDailyTasks() });
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.post("/admin/daily", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<{
    title?: string;
    body?: string;
    reward?: number;
    active?: boolean;
    sortOrder?: number;
  }>(c);
  try {
    return c.json(
      await daily.createDailyTask({
        title: input.title ?? "",
        body: input.body ?? "",
        reward: Math.min(Math.max(Number(input.reward ?? 0.01), 0), 10),
        active: input.active ?? true,
        sortOrder: input.sortOrder ?? 0,
      }),
    );
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.patch("/admin/daily/:id", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<{
    title?: string;
    body?: string;
    reward?: number;
    active?: boolean;
    sortOrder?: number;
  }>(c);
  try {
    return c.json(await daily.updateDailyTask(c.req.param("id"), input));
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.delete("/admin/daily/:id", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json(await daily.deleteDailyTask(c.req.param("id")));
  } catch (e) {
    return fail(c, e);
  }
});

// ── admin: settings ──────────────────────────────────────────────────────────

mobileApi.get("/admin/settings", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  try {
    return c.json(await q.getSettings());
  } catch (e) {
    return fail(c, e);
  }
});

mobileApi.put("/admin/settings", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<Partial<SiteSettings>>(c);
  const L = SETTING_LIMITS;
  const clamp = (v: unknown, fallback: number, min: number, max: number) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(Math.max(n, min), max);
  };
  const next: SiteSettings = {
    baseRatePerHour: clamp(input.baseRatePerHour, DEFAULT_SETTINGS.baseRatePerHour, L.baseRatePerHour.min, L.baseRatePerHour.max),
    boostPerMemberPerHour: clamp(
      input.boostPerMemberPerHour,
      DEFAULT_SETTINGS.boostPerMemberPerHour,
      L.boostPerMemberPerHour.min,
      L.boostPerMemberPerHour.max,
    ),
    maxBoostMembers: Math.round(
      clamp(input.maxBoostMembers, DEFAULT_SETTINGS.maxBoostMembers, L.maxBoostMembers.min, L.maxBoostMembers.max),
    ),
    referralBonus: clamp(input.referralBonus, DEFAULT_SETTINGS.referralBonus, L.referralBonus.min, L.referralBonus.max),
    sessionHours: clamp(input.sessionHours, DEFAULT_SETTINGS.sessionHours, L.sessionHours.min, L.sessionHours.max),
    maintenanceMode: Boolean(input.maintenanceMode),
    maintenanceMessage: String(input.maintenanceMessage ?? DEFAULT_SETTINGS.maintenanceMessage).slice(0, 300),
    announcement: String(input.announcement ?? "").slice(0, 300),
  };
  try {
    return c.json(await admin.saveSettings(next));
  } catch (e) {
    return fail(c, e);
  }
});

// ── admin: own password ──────────────────────────────────────────────────────

mobileApi.post("/admin/password", async (c) => {
  const gate = await requireAdmin(c);
  if (gate instanceof Response) return gate;
  const input = await body<{ currentPassword?: string; newPassword?: string }>(c);
  try {
    return c.json(await admin.changeOwnPassword(gate.id, input.currentPassword ?? "", input.newPassword ?? ""));
  } catch (e) {
    return fail(c, e);
  }
});

// `authProvider` is imported for parity with the website's auth seam; the phone
// app issues its own token instead of a cookie, so it is not called here.
void authProvider;
