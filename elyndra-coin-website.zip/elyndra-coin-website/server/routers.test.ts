import { beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";
import { makeCaller } from "./_core/test-caller";

// Full rationale for what gets mocked below (and why ./_core/trpc doesn't
// need to be) lives on server/_core/test-caller.ts, next to makeCaller —
// mock every _core module routers.ts touches.
vi.mock("./_core/auth", () => {
  class AuthError extends Error {}
  return {
    authProvider: () => ({ login: vi.fn(), logout: vi.fn(), getSession: vi.fn() }),
    registerLocalUser: vi.fn(),
    AuthError,
    EmailTakenError: class EmailTakenError extends AuthError {},
  };
});

vi.mock("./_core/storage", () => ({
  storageCommit: vi.fn(),
  storageDeleteOwned: vi.fn(),
  storageListByOwner: vi.fn(),
  storagePutUrl: vi.fn(),
  StorageError: class StorageError extends Error {
    code: string;
    constructor(message: string, code: string) {
      super(message);
      this.code = code;
    }
  },
}));

// The business layer is mocked so these tests exercise the ROUTER's contract
// (owner scoping, error mapping) without a database. The mining engine itself
// is covered by shared/mining.test.ts, which needs no mocks at all.
vi.mock("./db", () => {
  class MiningError extends Error {}
  return {
    MiningError,
    ensureProfile: vi.fn(),
    getStatus: vi.fn(),
    startSession: vi.fn(),
    claimSession: vi.fn(),
    getTeam: vi.fn(),
    getLedger: vi.fn(),
    setUsername: vi.fn(),
    getSettings: vi.fn(),
  };
});

// The admin and daily layers import _core/db (and therefore env), so they are
// mocked here for the same reason as ./db: this file tests the router contract,
// not the SQL. Their real behaviour is exercised against the dev database.
vi.mock("./admin", () => {
  class AdminError extends Error {}
  return {
    AdminError,
    isAdminUser: vi.fn(),
    getStats: vi.fn(),
    listUsers: vi.fn(),
    listSessions: vi.fn(),
    listReferrals: vi.fn(),
    listLedger: vi.fn(),
    setUserSuspended: vi.fn(),
    saveSettings: vi.fn(),
    listTasks: vi.fn(),
    listPublicTasks: vi.fn(),
    createTask: vi.fn(),
    updateTask: vi.fn(),
    deleteTask: vi.fn(),
  };
});

vi.mock("./daily", () => ({
  getDailyProgress: vi.fn(),
  completeDailyTask: vi.fn(),
  listDailyTasks: vi.fn(),
  createDailyTask: vi.fn(),
  updateDailyTask: vi.fn(),
  deleteDailyTask: vi.fn(),
}));

const { sanitizeBasename } = await import("./routers");
const { storageDeleteOwned, StorageError } = await import("./_core/storage");
const { registerLocalUser, EmailTakenError } = await import("./_core/auth");
const q = await import("./db");
const adminLayer = await import("./admin");
const dailyLayer = await import("./daily");

// C1c: uploadUrl's key is `${uuid}-${sanitizeBasename(name)}`. The uuid prefix
// only makes the key unguessable if the REST of the key isn't
// attacker-controlled — sanitizeBasename is what stops a caller-supplied
// `name` like "/../report.pdf" from steering path segments into someone
// else's key (which canonicalKey in storage.ts would then reject outright,
// but the point of sanitizing here is to never construct that key at all).
describe("sanitizeBasename", () => {
  it("passes a normal filename through unchanged", () => {
    expect(sanitizeBasename("report.pdf")).toBe("report.pdf");
  });

  it("takes only the last path segment, dropping any directory traversal", () => {
    expect(sanitizeBasename("/../report.pdf")).toBe("report.pdf");
    expect(sanitizeBasename("a/b/../evil.png")).toBe("evil.png");
    expect(sanitizeBasename("../../etc/passwd")).toBe("passwd");
  });

  it("strips characters outside [A-Za-z0-9._-]", () => {
    expect(sanitizeBasename("my file (final)!.png")).toBe("myfilefinal.png");
    expect(sanitizeBasename("héllo.png")).toBe("hllo.png");
  });

  it("collapses leading dots so a bare '.' or '..' basename can't survive", () => {
    expect(sanitizeBasename("..")).toBe("upload");
    expect(sanitizeBasename(".")).toBe("upload");
    expect(sanitizeBasename("...hidden")).toBe("upload.hidden");
  });

  it("keeps the extension when the stem is entirely non-ASCII", () => {
    expect(sanitizeBasename("风景.png")).toBe("upload.png");
    expect(sanitizeBasename("日本語.jpeg")).toBe("upload.jpeg");
    expect(sanitizeBasename("한글.png")).toBe("upload.png");
    expect(sanitizeBasename("相册/风景.png")).toBe("upload.png");
  });

  it("keeps the extension on names that already sanitized cleanly", () => {
    expect(sanitizeBasename("微信图片_2026.png")).toBe("_2026.png");
    expect(sanitizeBasename("IMG_1234.PNG")).toBe("IMG_1234.PNG");
    expect(sanitizeBasename("archive.tar.gz")).toBe("archive.tar.gz");
  });

  it("treats a leading-dot name as a stem, not as a bare extension", () => {
    expect(sanitizeBasename(".png")).toBe("png");
    expect(sanitizeBasename(".gitignore")).toBe("gitignore");
  });

  it("never emits a path separator, and caps the extension", () => {
    expect(sanitizeBasename("C:\\photos\\风景.png")).toBe("upload.png");
    expect(sanitizeBasename("x." + "a".repeat(40))).toBe("x." + "a".repeat(10));
  });

  it("falls back to a constant when nothing survives sanitization", () => {
    expect(sanitizeBasename("???")).toBe("upload");
    expect(sanitizeBasename("")).toBe("upload");
    expect(sanitizeBasename("///")).toBe("upload");
  });
});

// C1d (regression): storageDeleteOwned runs the key through canonicalKey,
// which throws StorageError("forbidden") for a malformed key (e.g. a
// "../"-traversal segment) BEFORE any db/network access. files.remove had no
// try/catch, so that throw used to escape as a raw StorageError, which tRPC
// wraps as an opaque INTERNAL_SERVER_ERROR (500) for what is plainly bad
// client input.
describe("files.remove", () => {
  it("maps a malformed key (StorageError forbidden) to TRPCError BAD_REQUEST, not a raw throw", async () => {
    vi.mocked(storageDeleteOwned).mockRejectedValueOnce(
      new StorageError("unsafe storage key (diverges from platform normalization): ../evil.pdf", "forbidden"),
    );
    const caller = makeCaller({
      c: {} as never,
      db: {} as never,
      user: { id: "user-1" } as never,
    });

    const err = await caller.files.remove({ key: "../evil.pdf" }).catch((e) => e);

    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("BAD_REQUEST");
  });
});

// Regression (observed 2026-08-26, published app): signing up twice with the
// same email answered 500 INTERNAL_SERVER_ERROR whose message was the raw
// Drizzle failure — the INSERT statement plus every bound param, bcrypt hash
// included — which the signup form then printed at the user.
describe("auth.signup", () => {
  const anonymous = { c: {} as never, db: {} as never, user: null };

  it("maps an already-registered email to TRPCError CONFLICT, not a 500", async () => {
    vi.mocked(registerLocalUser).mockRejectedValueOnce(
      new EmailTakenError("That email is already registered — try logging in instead."),
    );
    const caller = makeCaller(anonymous);

    const err = await caller.auth
      .signup({ email: "asce1885@gmail.com", password: "hunter2hunter2", name: "asce" })
      .catch((e) => e);

    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("CONFLICT");
    expect((err as TRPCError).message).toMatch(/already registered/i);
    expect((err as TRPCError).message).not.toMatch(/insert into|Failed query|params:|\$2b\$/);
  });
});

// ── Mining router ───────────────────────────────────────────────────────────
// The security property that matters: every mining procedure acts on
// ctx.user.id and nothing else. A caller cannot name another user, and cannot
// pass an amount, a rate or a timestamp — the input schemas have no such field.
describe("mining router", () => {
  // Each case asserts on call counts, so the mocks must not carry over.
  beforeEach(() => vi.clearAllMocks());

  const asUser = (id: string) =>
    makeCaller({ c: {} as never, db: {} as never, user: { id } as never });

  it("scopes status to the caller's own id", async () => {
    vi.mocked(q.getStatus).mockResolvedValueOnce({} as never);
    await asUser("user-42").mining.status();
    expect(q.getStatus).toHaveBeenCalledWith("user-42");
  });

  it("scopes start to the caller's own id", async () => {
    vi.mocked(q.startSession).mockResolvedValueOnce({} as never);
    vi.mocked(q.getStatus).mockResolvedValueOnce({} as never);
    await asUser("user-42").mining.start();
    expect(q.startSession).toHaveBeenCalledWith("user-42");
  });

  it("scopes claim to the caller's own id", async () => {
    vi.mocked(q.claimSession).mockResolvedValueOnce({ amount: 0.1416, credited: 0.1416 });
    vi.mocked(q.getStatus).mockResolvedValueOnce({} as never);
    await asUser("user-42").mining.claim();
    expect(q.claimSession).toHaveBeenCalledWith("user-42");
  });

  it("scopes team and ledger to the caller's own id", async () => {
    vi.mocked(q.getTeam).mockResolvedValueOnce({} as never);
    vi.mocked(q.getLedger).mockResolvedValueOnce([]);
    const caller = asUser("user-42");
    await caller.mining.team();
    await caller.mining.ledger();
    expect(q.getTeam).toHaveBeenCalledWith("user-42");
    expect(q.getLedger).toHaveBeenCalledWith("user-42");
  });

  it("rejects an anonymous caller on every mining procedure", async () => {
    const anonymous = makeCaller({ c: {} as never, db: {} as never, user: null });
    for (const call of [
      () => anonymous.mining.status(),
      () => anonymous.mining.start(),
      () => anonymous.mining.claim(),
      () => anonymous.mining.team(),
      () => anonymous.mining.ledger(),
    ]) {
      const err = await call().catch((e) => e);
      expect(err).toBeInstanceOf(TRPCError);
      expect((err as TRPCError).code).toBe("UNAUTHORIZED");
    }
  });

  it("maps a domain failure to BAD_REQUEST with the user-facing message", async () => {
    const { MiningError } = await import("./db");
    vi.mocked(q.startSession).mockRejectedValueOnce(
      new MiningError("Your session is already running — it ends on its own."),
    );
    const err = await asUser("user-42").mining.start().catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("BAD_REQUEST");
    expect((err as TRPCError).message).toMatch(/already running/i);
  });

  it("does not let a caller supply an amount, a rate or a timestamp", async () => {
    // The input schemas are the contract: `start` and `claim` take no input at
    // all, so an injected `{ amount: 9999 }` is simply ignored by tRPC.
    vi.mocked(q.startSession).mockResolvedValueOnce({} as never);
    vi.mocked(q.getStatus).mockResolvedValueOnce({} as never);
    await asUser("user-42").mining.start({ amount: 9999 } as never);
    expect(q.startSession).toHaveBeenCalledWith("user-42");
    expect(q.startSession).toHaveBeenCalledTimes(1);
  });
});

// ── Admin router ──────────────────────────────────────────────────────────────
// The property that matters most: the console is unreachable without the admin
// role. A signed-in normal user must get FORBIDDEN on every procedure, and an
// anonymous caller UNAUTHORIZED — the client-side gate is convenience, this is
// the actual boundary.
describe("admin router", () => {
  beforeEach(() => vi.clearAllMocks());

  const asUser = (id: string, role: "user" | "admin" = "user") =>
    makeCaller({ c: {} as never, db: {} as never, user: { id, role } as never });

  it("rejects an anonymous caller on every admin procedure", async () => {
    const anonymous = makeCaller({ c: {} as never, db: {} as never, user: null });
    for (const call of [
      () => anonymous.admin.stats(),
      () => anonymous.admin.users({ limit: 10 }),
      () => anonymous.admin.sessions({ limit: 10 }),
      () => anonymous.admin.referrals(),
      () => anonymous.admin.ledger(),
      () => anonymous.admin.settings(),
      () => anonymous.admin.tasks(),
      () => anonymous.admin.dailyTasks(),
    ]) {
      const err = await call().catch((e) => e);
      expect(err).toBeInstanceOf(TRPCError);
      expect((err as TRPCError).code).toBe("UNAUTHORIZED");
    }
  });

  it("rejects a signed-in non-admin with FORBIDDEN", async () => {
    const err = await asUser("user-1", "user")
      .admin.stats()
      .catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("FORBIDDEN");
    // The data layer must never have been reached.
    expect(adminLayer.getStats).not.toHaveBeenCalled();
  });

  it("lets an admin read the user and session lists", async () => {
    vi.mocked(adminLayer.listUsers).mockResolvedValueOnce([]);
    vi.mocked(adminLayer.listSessions).mockResolvedValueOnce([]);
    const caller = asUser("admin-1", "admin");
    await caller.admin.users({ limit: 25 });
    await caller.admin.sessions({ limit: 25 });
    expect(adminLayer.listUsers).toHaveBeenCalledWith(25);
    expect(adminLayer.listSessions).toHaveBeenCalledWith(25);
  });

  it("refuses to let an admin suspend their own account", async () => {
    const err = await asUser("admin-1", "admin")
      .admin.suspendUser({ userId: "admin-1", suspended: true })
      .catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("BAD_REQUEST");
    expect(adminLayer.setUserSuspended).not.toHaveBeenCalled();
  });

  it("maps an admin domain failure to BAD_REQUEST", async () => {
    const { AdminError } = await import("./admin");
    vi.mocked(adminLayer.setUserSuspended).mockRejectedValueOnce(
      new AdminError("That account has no mining profile yet."),
    );
    const err = await asUser("admin-1", "admin")
      .admin.suspendUser({ userId: "user-9", suspended: true })
      .catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("BAD_REQUEST");
  });
});

// ── Daily tasks ───────────────────────────────────────────────────────────────
// Same owner-scoping rule as mining: the caller cannot name another user, and
// the reward is decided server-side from the task row.
describe("daily router", () => {
  beforeEach(() => vi.clearAllMocks());

  const asUser = (id: string) =>
    makeCaller({ c: {} as never, db: {} as never, user: { id } as never });

  it("scopes progress and completion to the caller's own id", async () => {
    vi.mocked(dailyLayer.getDailyProgress).mockResolvedValueOnce({} as never);
    vi.mocked(dailyLayer.completeDailyTask).mockResolvedValueOnce({ amount: 0.01 } as never);
    const caller = asUser("user-7");
    await caller.daily.progress();
    await caller.daily.complete({ taskId: "11111111-1111-4111-8111-111111111111" });
    expect(dailyLayer.getDailyProgress).toHaveBeenCalledWith("user-7");
    expect(dailyLayer.completeDailyTask).toHaveBeenCalledWith(
      "user-7",
      "11111111-1111-4111-8111-111111111111",
    );
  });

  it("rejects an anonymous caller", async () => {
    const anonymous = makeCaller({ c: {} as never, db: {} as never, user: null });
    const err = await anonymous.daily.progress().catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("UNAUTHORIZED");
  });
});

// ── Signup name is compulsory ─────────────────────────────────────────────────
// The form marks the field `required`, but the API is the real gate: a request
// that omits the name, or sends only whitespace, must be refused before any
// account is created.
describe("auth.signup name is compulsory", () => {
  const anonymous = { c: {} as never, db: {} as never, user: null };

  it("refuses a signup with no name", async () => {
    const err = await makeCaller(anonymous)
      .auth.signup({ email: "a@example.com", password: "hunter2hunter2" } as never)
      .catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("BAD_REQUEST");
    expect(registerLocalUser).not.toHaveBeenCalled();
  });

  it("refuses a name that is only whitespace", async () => {
    const err = await makeCaller(anonymous)
      .auth.signup({ email: "a@example.com", password: "hunter2hunter2", name: "   " })
      .catch((e) => e);
    expect(err).toBeInstanceOf(TRPCError);
    expect((err as TRPCError).code).toBe("BAD_REQUEST");
    expect(registerLocalUser).not.toHaveBeenCalled();
  });

  it("accepts a real name and passes it through trimmed", async () => {
    vi.mocked(registerLocalUser).mockResolvedValueOnce({ id: "u1" } as never);
    vi.mocked(q.ensureProfile).mockResolvedValueOnce({} as never);
    await makeCaller(anonymous).auth.signup({
      email: "a@example.com",
      password: "hunter2hunter2",
      name: "  Ada Lovelace  ",
    });
    expect(registerLocalUser).toHaveBeenCalledWith("a@example.com", "hunter2hunter2", "Ada Lovelace");
  });
});
