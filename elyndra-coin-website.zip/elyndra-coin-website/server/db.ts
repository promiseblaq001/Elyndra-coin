// ── AGENT-OWNED: business data-access ────────────────────────────────────────
// The mining engine. Every number a user sees is derived here from timestamps
// and stored rates — never from anything the client sends — so a closed app
// keeps accruing and an open one cannot inflate its balance.
import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { atomic, db, isUniqueViolation } from "./_core/db";
import { ledger, miningSessions, profiles, referrals, siteSettings } from "../drizzle/schema";
import {
  accrualFor,
  round6,
  sessionProgress,
  type LedgerEntryView,
  type LedgerType,
  type MiningStatus,
  type TeamView,
} from "../shared/mining";
import { DEFAULT_SETTINGS, parseSettings, type SiteSettings } from "../shared/admin";

/** A failure the user can act on — routers map it to a TRPCError. */
export class MiningError extends Error {}

/** Never matches a real row; used to make a guarded statement a no-op. */
const NIL_UUID = "00000000-0000-0000-0000-000000000000";

// No 0/O/1/I: referral codes get read aloud and typed by hand.
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomCode(len = 6): string {
  const bytes = crypto.getRandomValues(new Uint8Array(len));
  return Array.from(bytes, (b) => CODE_ALPHABET[b % CODE_ALPHABET.length]).join("");
}

// ── profiles ────────────────────────────────────────────────────────────────

export async function getProfile(userId: string) {
  const [row] = await db.select().from(profiles).where(eq(profiles.userId, userId)).limit(1);
  return row ?? null;
}

// ── settings ──────────────────────────────────────────────────────────────────

/**
 * The live economy, as the admin last saved it. Read on every start/status so a
 * change in the dashboard takes effect on the next session without a deploy.
 * A missing table or an unreadable row falls back to the defaults.
 */
export async function getSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.select().from(siteSettings);
    return parseSettings(rows.map((r) => ({ key: r.key, value: r.value })));
  } catch {
    return DEFAULT_SETTINGS;
  }
}

/** Boost rate for a given active-member count, using the live settings. */
function boostFor(activeMembers: number, s: SiteSettings): number {
  const capped = Math.min(Math.max(Math.floor(activeMembers), 0), s.maxBoostMembers);
  return round6(capped * s.boostPerMemberPerHour);
}

/**
 * Bind a new account to the referrer whose code they signed up with. Best
 * effort: a bad or unknown code must never block a signup.
 */
async function bindReferral(userId: string, refCode: string): Promise<void> {
  const code = refCode.trim().toUpperCase();
  if (!code) return;
  const [referrer] = await db
    .select()
    .from(profiles)
    .where(eq(profiles.referralCode, code))
    .limit(1);
  if (!referrer || referrer.userId === userId) return;
  await db.update(profiles).set({ referredById: referrer.userId }).where(eq(profiles.userId, userId));
  await db
    .insert(referrals)
    .values({ referrerId: referrer.userId, refereeId: userId })
    .onConflictDoNothing();
}

/**
 * Get the caller's profile, creating it on first touch. `refCode` is only used
 * on that first creation, so a referral link works even if the user closes the
 * tab between signing up and opening the mining screen.
 */
export async function ensureProfile(userId: string, refCode?: string) {
  const existing = await getProfile(userId);
  if (existing) return existing;

  for (let attempt = 0; attempt < 6; attempt++) {
    try {
      const [row] = await db
        .insert(profiles)
        .values({
          userId,
          username: `miner_${randomCode(6).toLowerCase()}`,
          referralCode: randomCode(6),
        })
        .returning();
      if (refCode) {
        try {
          await bindReferral(userId, refCode);
        } catch {
          // A referral that cannot be bound is not a signup failure.
        }
      }
      return row;
    } catch (e) {
      // Username or code collision — draw again.
      if (isUniqueViolation(e)) continue;
      throw e;
    }
  }
  throw new MiningError("Could not allocate a profile — please try again.");
}

export async function setUsername(userId: string, username: string) {
  const clean = username.trim();
  if (!/^[A-Za-z0-9_]{3,20}$/.test(clean)) {
    throw new MiningError("Usernames are 3–20 characters: letters, numbers and underscores only.");
  }
  try {
    const [row] = await db
      .update(profiles)
      .set({ username: clean })
      .where(eq(profiles.userId, userId))
      .returning();
    return row;
  } catch (e) {
    if (isUniqueViolation(e)) throw new MiningError("That username is taken — try another.");
    throw e;
  }
}

// ── sessions ────────────────────────────────────────────────────────────────

async function getOpenSession(userId: string) {
  const [row] = await db
    .select()
    .from(miningSessions)
    .where(and(eq(miningSessions.userId, userId), eq(miningSessions.claimed, false)))
    .limit(1);
  return row ?? null;
}

async function circleCounts(userId: string) {
  const rows = await db
    .select({ active: referrals.active })
    .from(referrals)
    .where(eq(referrals.referrerId, userId));
  return { active: rows.filter((r) => r.active).length, total: rows.length };
}

/** Open a 24-hour session. Rates are locked in at start, as Pi does. */
export async function startSession(userId: string) {
  await ensureProfile(userId);

  const open = await getOpenSession(userId);
  if (open) {
    if (open.endsAt.getTime() > Date.now()) {
      throw new MiningError("Your session is already running — it ends on its own.");
    }
    throw new MiningError("Your last session has finished. Claim it to open the next one.");
  }

  const profile = await getProfile(userId);
  if (profile?.suspended) {
    throw new MiningError("This account is suspended — contact the network admin.");
  }

  const settings = await getSettings();
  if (settings.maintenanceMode) {
    throw new MiningError(settings.maintenanceMessage);
  }

  const counts = await circleCounts(userId);
  const now = new Date();
  const [row] = await db
    .insert(miningSessions)
    .values({
      userId,
      startedAt: now,
      endsAt: new Date(now.getTime() + settings.sessionHours * 60 * 60 * 1000),
      baseRate: settings.baseRatePerHour,
      boostRate: boostFor(counts.active, settings),
    })
    // The partial unique index on (user_id) WHERE claimed = false is the real
    // guard: two simultaneous taps cannot both open a session.
    .onConflictDoNothing()
    .returning();

  if (!row) throw new MiningError("A session is already open.");

  // Starting a session is what makes a referee "active" in their referrer's
  // Security Circle — that is the moment the boost starts counting.
  await db
    .update(referrals)
    .set({ active: true })
    .where(and(eq(referrals.refereeId, userId), eq(referrals.active, false)));

  return row;
}

/**
 * Close a finished session: credit the accrued amount, write the ledger row,
 * and — if this is the referee's first claim — pay the referrer's one-time
 * bonus. All of it lands in one atomic batch, and every statement after the
 * first is guarded by `claim_ref`, so a double-tap credits exactly once.
 */
export async function claimSession(userId: string) {
  const open = await getOpenSession(userId);
  if (!open) throw new MiningError("There is no session to claim. Start mining first.");

  const now = new Date();
  if (open.endsAt.getTime() > now.getTime()) {
    throw new MiningError("This session is still running — come back when the 24 hours are up.");
  }

  const amount = accrualFor({
    startedAt: open.startedAt,
    endsAt: open.endsAt,
    now,
    baseRate: open.baseRate,
    boostRate: open.boostRate,
  });

  const claimRef = crypto.randomUUID();
  const bonusRef = crypto.randomUUID();

  // Is this the referee's first claim? That is when the referrer's bonus is due.
  const [claimedCount] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(miningSessions)
    .where(and(eq(miningSessions.userId, userId), eq(miningSessions.claimed, true)));
  const isFirstClaim = (claimedCount?.n ?? 0) === 0;

  const [pending] = isFirstClaim
    ? await db
        .select()
        .from(referrals)
        .where(and(eq(referrals.refereeId, userId), isNull(referrals.bonusPaidAt)))
        .limit(1)
    : [];
  const referrerId = pending?.referrerId ?? NIL_UUID;
  const settings = await getSettings();
  const bonus = settings.referralBonus;

  // "This call won the claim" — the only way to tell our own write from a
  // concurrent one inside a single batch.
  const won = sql`exists (select 1 from ${miningSessions} where ${miningSessions.claimRef} = ${claimRef})`;
  const bonusWon = sql`exists (select 1 from ${referrals} where ${referrals.bonusRef} = ${bonusRef})`;

  await atomic((d) => [
    d
      .update(miningSessions)
      .set({ claimed: true, claimedAt: now, minedAmount: amount, claimRef })
      .where(and(eq(miningSessions.id, open.id), eq(miningSessions.claimed, false)))
      .returning(),

    d
      .update(profiles)
      .set({
        balance: sql`${profiles.balance} + ${amount}`,
        totalMined: sql`${profiles.totalMined} + ${amount}`,
      })
      .where(and(eq(profiles.userId, userId), won))
      .returning(),

    d.insert(ledger).select((qb) =>
      qb
        .select({
          id: sql`gen_random_uuid()`.as("id"),
          userId: sql`${userId}::uuid`.as("user_id"),
          amount: sql`${amount}::double precision`.as("amount"),
          type: sql`'mining'::text`.as("type"),
          note: sql`'24h mining session'::text`.as("note"),
          sessionId: sql`${open.id}::uuid`.as("session_id"),
          createdAt: sql`now()`.as("created_at"),
        })
        .from(miningSessions)
        .where(and(eq(miningSessions.id, open.id), eq(miningSessions.claimRef, claimRef))),
    ),

    // One-time referral bonus. With no pending referral, `referrerId` is the nil
    // uuid, so this matches nothing and the two statements below stay no-ops.
    d
      .update(referrals)
      .set({ bonusPaidAt: now, bonusRef })
      .where(
        and(
          eq(referrals.refereeId, userId),
          eq(referrals.referrerId, referrerId),
          isNull(referrals.bonusPaidAt),
          won,
        ),
      )
      .returning(),

    d
      .update(profiles)
      .set({ balance: sql`${profiles.balance} + ${bonus}` })
      .where(and(eq(profiles.userId, referrerId), bonusWon))
      .returning(),

    d.insert(ledger).select((qb) =>
      qb
        .select({
          id: sql`gen_random_uuid()`.as("id"),
          userId: sql`${referrerId}::uuid`.as("user_id"),
          amount: sql`${bonus}::double precision`.as("amount"),
          type: sql`'referral_bonus'::text`.as("type"),
          note: sql`'Security Circle referral bonus'::text`.as("note"),
          sessionId: sql`null::uuid`.as("session_id"),
          createdAt: sql`now()`.as("created_at"),
        })
        .from(referrals)
        .where(eq(referrals.bonusRef, bonusRef)),
    ),
  ]);

  return { amount, credited: round6(amount) };
}

// ── read models ─────────────────────────────────────────────────────────────

export async function getStatus(userId: string): Promise<MiningStatus> {
  const profile = await ensureProfile(userId);
  const session = await getOpenSession(userId);
  const counts = await circleCounts(userId);
  const settings = await getSettings();
  const now = new Date();

  // While a session is open its locked rates are the truth; between sessions the
  // figure shown is what the NEXT session would earn.
  const base = session ? session.baseRate : settings.baseRatePerHour;
  const boost = session ? session.boostRate : boostFor(counts.active, settings);

  return {
    profile: {
      username: profile.username,
      referralCode: profile.referralCode,
      balance: profile.balance,
      totalMined: profile.totalMined,
      createdAt: profile.createdAt.toISOString(),
    },
    session: session
      ? {
          id: session.id,
          startedAt: session.startedAt.toISOString(),
          endsAt: session.endsAt.toISOString(),
          baseRate: session.baseRate,
          boostRate: session.boostRate,
          accrued: accrualFor({
            startedAt: session.startedAt,
            endsAt: session.endsAt,
            now,
            baseRate: session.baseRate,
            boostRate: session.boostRate,
          }),
          claimed: session.claimed,
          remainingMs: Math.max(0, session.endsAt.getTime() - now.getTime()),
          progress: sessionProgress({
            startedAt: session.startedAt,
            endsAt: session.endsAt,
            now,
          }),
        }
      : null,
    rates: {
      base,
      boost,
      total: round6(base + boost),
      activeMembers: counts.active,
      maxMembers: settings.maxBoostMembers,
    },
    team: { active: counts.active, total: counts.total },
    suspended: profile.suspended,
    announcement: settings.announcement || null,
    serverNow: now.toISOString(),
  };
}

export async function getTeam(userId: string): Promise<TeamView> {
  const profile = await ensureProfile(userId);
  const settings = await getSettings();
  const rows = await db
    .select({
      username: profiles.username,
      active: referrals.active,
      joinedAt: referrals.createdAt,
    })
    .from(referrals)
    .innerJoin(profiles, eq(profiles.userId, referrals.refereeId))
    .where(eq(referrals.referrerId, userId))
    .orderBy(desc(referrals.createdAt));

  const active = rows.filter((r) => r.active).length;
  return {
    referralCode: profile.referralCode,
    members: rows.map((r) => ({
      username: r.username,
      active: r.active,
      joinedAt: r.joinedAt.toISOString(),
    })),
    activeMembers: active,
    maxMembers: settings.maxBoostMembers,
    boostRate: boostFor(active, settings),
    bonusPerReferral: settings.referralBonus,
  };
}

export async function getLedger(userId: string, limit = 100): Promise<LedgerEntryView[]> {
  const rows = await db
    .select()
    .from(ledger)
    .where(eq(ledger.userId, userId))
    .orderBy(desc(ledger.createdAt))
    .limit(limit);
  return rows.map((r) => ({
    id: r.id,
    amount: r.amount,
    type: r.type as LedgerType,
    note: r.note,
    createdAt: r.createdAt.toISOString(),
  }));
}
