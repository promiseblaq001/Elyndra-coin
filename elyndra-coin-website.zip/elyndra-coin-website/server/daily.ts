// ── AGENT-OWNED: daily tasks ──────────────────────────────────────────────────
// A daily task is completed once per UTC day, per user. The reward is credited
// in the same atomic batch that records the completion, and the unique index on
// (user_id, task_id, day) is what makes a double-tap pay exactly once.
import { and, desc, eq, sql } from "drizzle-orm";
import { atomic, db } from "./_core/db";
import { dailyCompletions, dailyTasks, ledger, profiles } from "../drizzle/schema";
import { round6 } from "../shared/mining";
import { dayKey, msUntilReset, type DailyProgress, type DailyTaskView } from "../shared/daily";
import { MiningError } from "./db";

/** Every active task, in display order. */
async function activeTasks() {
  return db
    .select()
    .from(dailyTasks)
    .where(eq(dailyTasks.active, true))
    .orderBy(dailyTasks.sortOrder, desc(dailyTasks.createdAt));
}

/**
 * Today's tasks with this user's completion state, plus the streak and the
 * amount earned today. One query for the tasks, one for today's completions,
 * one for the recent days the streak needs — no per-task round trips.
 */
export async function getDailyProgress(userId: string): Promise<DailyProgress> {
  const today = dayKey();
  const tasks = await activeTasks();

  const todayRows = await db
    .select()
    .from(dailyCompletions)
    .where(and(eq(dailyCompletions.userId, userId), eq(dailyCompletions.day, today)));

  const doneByTask = new Map(todayRows.map((r) => [r.taskId, r]));

  // Streak: walk back from today (or yesterday, if today is still untouched)
  // over the distinct days this user completed anything.
  const recent = await db
    .selectDistinct({ day: dailyCompletions.day })
    .from(dailyCompletions)
    .where(eq(dailyCompletions.userId, userId))
    .orderBy(desc(dailyCompletions.day))
    .limit(400);
  const days = new Set(recent.map((r) => r.day));

  let streak = 0;
  const cursor = new Date(`${today}T00:00:00.000Z`);
  // If nothing was done today, the streak is measured up to yesterday — a
  // streak is not broken until a whole day passes with nothing.
  if (!days.has(today)) cursor.setUTCDate(cursor.getUTCDate() - 1);
  for (;;) {
    const key = dayKey(cursor);
    if (!days.has(key)) break;
    streak += 1;
    cursor.setUTCDate(cursor.getUTCDate() - 1);
  }

  const views: DailyTaskView[] = tasks.map((t) => {
    const row = doneByTask.get(t.id);
    return {
      id: t.id,
      title: t.title,
      body: t.body,
      reward: t.reward,
      done: Boolean(row),
      completedAt: row ? row.createdAt.toISOString() : null,
    };
  });

  return {
    day: today,
    tasks: views,
    completedCount: views.filter((v) => v.done).length,
    totalCount: views.length,
    earnedToday: round6(todayRows.reduce((sum, r) => sum + r.amount, 0)),
    streak,
    resetsInMs: msUntilReset(),
  };
}

/**
 * Complete a task for today. The insert is guarded by the unique index, so a
 * concurrent second call inserts nothing and pays nothing — the balance update
 * is conditional on this call having actually created the row.
 */
export async function completeDailyTask(userId: string, taskId: string) {
  const [task] = await db.select().from(dailyTasks).where(eq(dailyTasks.id, taskId)).limit(1);
  if (!task || !task.active) throw new MiningError("That task is not available.");

  const today = dayKey();
  const amount = round6(task.reward);
  const completionId = crypto.randomUUID();

  // "This call won the completion" — the only way to tell our own insert from a
  // concurrent one inside a single batch.
  const won = sql`exists (select 1 from ${dailyCompletions} where ${dailyCompletions.id} = ${completionId})`;

  await atomic((d) => [
    d
      .insert(dailyCompletions)
      .values({ id: completionId, userId, taskId, day: today, amount })
      .onConflictDoNothing()
      .returning(),

    d
      .update(profiles)
      .set({ balance: sql`${profiles.balance} + ${amount}` })
      .where(and(eq(profiles.userId, userId), won))
      .returning(),

    d.insert(ledger).select((qb) =>
      qb
        .select({
          id: sql`gen_random_uuid()`.as("id"),
          userId: sql`${userId}::uuid`.as("user_id"),
          amount: sql`${amount}::double precision`.as("amount"),
          type: sql`'daily_task'::text`.as("type"),
          note: sql`${`Daily task: ${task.title}`}::text`.as("note"),
          sessionId: sql`null::uuid`.as("session_id"),
          createdAt: sql`now()`.as("created_at"),
        })
        .from(dailyCompletions)
        .where(eq(dailyCompletions.id, completionId)),
    ),
  ]);

  const [check] = await db
    .select()
    .from(dailyCompletions)
    .where(eq(dailyCompletions.id, completionId))
    .limit(1);

  if (!check) {
    throw new MiningError("You have already completed this task today — it resets at midnight UTC.");
  }

  return { amount, progress: await getDailyProgress(userId) };
}

// ── admin ─────────────────────────────────────────────────────────────────────

export interface AdminDailyTaskRow {
  id: string;
  title: string;
  body: string;
  reward: number;
  active: boolean;
  sortOrder: number;
  /** How many times it has been completed, all time. */
  completions: number;
  createdAt: string;
}

export async function listDailyTasks(): Promise<AdminDailyTaskRow[]> {
  const rows = await db
    .select({
      id: dailyTasks.id,
      title: dailyTasks.title,
      body: dailyTasks.body,
      reward: dailyTasks.reward,
      active: dailyTasks.active,
      sortOrder: dailyTasks.sortOrder,
      createdAt: dailyTasks.createdAt,
      completions: sql<number>`(
        select count(*)::int from ${dailyCompletions}
        where ${dailyCompletions.taskId} = ${dailyTasks.id}
      )`,
    })
    .from(dailyTasks)
    .orderBy(dailyTasks.sortOrder, desc(dailyTasks.createdAt));

  return rows.map((r) => ({
    id: r.id,
    title: r.title,
    body: r.body,
    reward: r.reward,
    active: r.active,
    sortOrder: r.sortOrder,
    completions: r.completions ?? 0,
    createdAt: r.createdAt.toISOString(),
  }));
}

export async function createDailyTask(input: {
  title: string;
  body: string;
  reward: number;
  active: boolean;
  sortOrder: number;
}) {
  const title = input.title.trim();
  if (!title) throw new MiningError("A daily task needs a title.");
  const [row] = await db
    .insert(dailyTasks)
    .values({
      title,
      body: input.body.trim(),
      reward: round6(input.reward),
      active: input.active,
      sortOrder: input.sortOrder,
    })
    .returning();
  return row;
}

export async function updateDailyTask(
  id: string,
  patch: Partial<{ title: string; body: string; reward: number; active: boolean; sortOrder: number }>,
) {
  const set: Record<string, unknown> = {};
  if (patch.title !== undefined) {
    const t = patch.title.trim();
    if (!t) throw new MiningError("A daily task needs a title.");
    set.title = t;
  }
  if (patch.body !== undefined) set.body = patch.body.trim();
  if (patch.reward !== undefined) set.reward = round6(patch.reward);
  if (patch.active !== undefined) set.active = patch.active;
  if (patch.sortOrder !== undefined) set.sortOrder = patch.sortOrder;

  const [row] = await db.update(dailyTasks).set(set).where(eq(dailyTasks.id, id)).returning();
  if (!row) throw new MiningError("That daily task no longer exists.");
  return row;
}

export async function deleteDailyTask(id: string) {
  const [row] = await db.delete(dailyTasks).where(eq(dailyTasks.id, id)).returning();
  if (!row) throw new MiningError("That daily task no longer exists.");
  return { ok: true as const };
}
