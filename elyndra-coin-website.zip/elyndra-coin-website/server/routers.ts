// ── AGENT-OWNED: tRPC API surface ────────────────────────────────────────────
// Compose the app's procedures here. Keep them thin: validate input with zod,
// call server/db.ts for data and server/services/* for external integrations.
// Auth is provided by _core — do NOT reimplement sessions. Access levels:
// publicProcedure (anyone) / protectedProcedure (ctx.user set) / adminProcedure.
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { router, publicProcedure, protectedProcedure, adminProcedure } from "./_core/trpc";
import { authProvider, registerLocalUser, AuthError, EmailTakenError } from "./_core/auth";
import { storageCommit, storageDeleteOwned, storageListByOwner, storagePutUrl, StorageError } from "./_core/storage";
import * as q from "./db";
import { MiningError } from "./db";
import * as admin from "./admin";
import { AdminError } from "./admin";
import * as daily from "./daily";
import { DEFAULT_SETTINGS, SETTING_LIMITS, type SiteSettings, type TaskKind } from "../shared/admin";

/** Map a domain failure to the tRPC code the client can act on. */
function asTrpc(e: unknown): never {
  if (e instanceof MiningError) throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
  throw e;
}

/** Same, for the admin surface. */
function asAdminTrpc(e: unknown): never {
  if (e instanceof AdminError) throw new TRPCError({ code: "BAD_REQUEST", message: e.message });
  throw e;
}

// Auth: login/logout are provider-agnostic (go through the AuthProvider).
// signup is LOCAL-only (SSO signup happens at the IdP) — guard if you switch.
const authRouter = router({
  me: publicProcedure.query(({ ctx }) => ctx.user),

  signup: publicProcedure
    .input(
      z.object({
        email: z.email(),
        password: z.string().min(8),
        /**
         * Compulsory. Trimmed and length-checked here, so a form that skips the
         * field (or posts only spaces) is refused by the API, not just by the
         * browser's `required` attribute.
         */
        name: z
          .string()
          .trim()
          .min(2, "Please enter your name (at least 2 characters).")
          .max(60, "That name is too long."),
        /** Referral code from `?ref=CODE` — binds the new account to its inviter. */
        refCode: z.string().max(16).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const user = await registerLocalUser(input.email, input.password, input.name);
        await authProvider().login(ctx.c, input.email, input.password); // set session cookie
        // Create the mining profile now, so the referral edge exists even if the
        // user never opens /mine in this browser session.
        try {
          await q.ensureProfile(user.id, input.refCode);
        } catch {
          // A profile that cannot be created yet is retried on first /mine load.
        }
        // If this address is on the ADMIN_EMAILS allowlist, promote it now so the
        // owner's very first signup already has the console.
        try {
          await admin.syncAdminRole(user.id, user.email);
        } catch {
          // Promotion is retried on the next admin.whoami call.
        }
        return user;
      } catch (e: unknown) {
        // CONFLICT, not a 500: the request was well-formed, the address is just
        // taken. registerLocalUser has already turned the driver's SQLSTATE
        // 23505 into this type — never pattern-match a DB error message here,
        // Drizzle hides it behind a "Failed query: <sql>" wrapper.
        if (e instanceof EmailTakenError) throw new TRPCError({ code: "CONFLICT", message: e.message });
        throw e;
      }
    }),

  login: publicProcedure
    .input(z.object({ email: z.email(), password: z.string() }))
    .mutation(async ({ ctx, input }) => {
      try {
        return await authProvider().login(ctx.c, input.email, input.password);
      } catch (e) {
        if (e instanceof AuthError) throw new TRPCError({ code: "UNAUTHORIZED", message: e.message });
        throw e;
      }
    }),

  logout: publicProcedure.mutation(async ({ ctx }) => {
    await authProvider().logout(ctx.c);
    return { ok: true };
  }),
});

// ── Mining ──────────────────────────────────────────────────────────────────
// Every procedure is owner-scoped through ctx.user.id. Nothing here accepts an
// amount, a rate or a timestamp from the client: the server derives all of it.
const miningRouter = router({
  status: protectedProcedure.query(({ ctx }) => q.getStatus(ctx.user.id)),

  start: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      await q.startSession(ctx.user.id);
      return await q.getStatus(ctx.user.id);
    } catch (e) {
      asTrpc(e);
    }
  }),

  claim: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      const result = await q.claimSession(ctx.user.id);
      return { ...result, status: await q.getStatus(ctx.user.id) };
    } catch (e) {
      asTrpc(e);
    }
  }),

  team: protectedProcedure.query(({ ctx }) => q.getTeam(ctx.user.id)),

  ledger: protectedProcedure.query(({ ctx }) => q.getLedger(ctx.user.id)),

  setUsername: protectedProcedure
    .input(z.object({ username: z.string().min(3).max(20) }))
    .mutation(async ({ ctx, input }) => {
      try {
        const row = await q.setUsername(ctx.user.id, input.username);
        return { username: row.username };
      } catch (e) {
        asTrpc(e);
      }
    }),

  /**
   * What the admin has published to the network. Public on purpose: the landing
   * page shows announcements to signed-out visitors too, and a task list is not
   * private data. Only `active` rows are ever returned.
   */
  tasks: publicProcedure.query(() => admin.listPublicTasks()),
});

// ── Daily tasks ───────────────────────────────────────────────────────────────
// Owner-scoped: the progress and the completion both act on ctx.user.id only.
const dailyRouter = router({
  progress: protectedProcedure.query(({ ctx }) => daily.getDailyProgress(ctx.user.id)),

  complete: protectedProcedure
    .input(z.object({ taskId: z.uuid() }))
    .mutation(async ({ ctx, input }) => {
      try {
        return await daily.completeDailyTask(ctx.user.id, input.taskId);
      } catch (e) {
        asTrpc(e);
      }
    }),
});

// ── Admin ─────────────────────────────────────────────────────────────────────
// Every procedure here is adminProcedure: a signed-in user whose role is
// 'admin'. A normal account gets FORBIDDEN, an anonymous caller UNAUTHORIZED.
const settingsInput = z.object({
  baseRatePerHour: z.number().min(SETTING_LIMITS.baseRatePerHour.min).max(SETTING_LIMITS.baseRatePerHour.max),
  boostPerMemberPerHour: z
    .number()
    .min(SETTING_LIMITS.boostPerMemberPerHour.min)
    .max(SETTING_LIMITS.boostPerMemberPerHour.max),
  maxBoostMembers: z
    .number()
    .int()
    .min(SETTING_LIMITS.maxBoostMembers.min)
    .max(SETTING_LIMITS.maxBoostMembers.max),
  referralBonus: z.number().min(SETTING_LIMITS.referralBonus.min).max(SETTING_LIMITS.referralBonus.max),
  sessionHours: z.number().min(SETTING_LIMITS.sessionHours.min).max(SETTING_LIMITS.sessionHours.max),
  maintenanceMode: z.boolean(),
  maintenanceMessage: z.string().max(300),
  announcement: z.string().max(300),
});

const taskKind = z.enum(["task", "announcement"]);

const adminRouter = router({
  /** Cheap gate the dashboard calls before rendering anything. */
  whoami: protectedProcedure.query(async ({ ctx }) => {
    // Promote on read as well as on signup: an owner who adds their address to
    // ADMIN_EMAILS after registering gets the console on the next visit.
    try {
      await admin.syncAdminRole(ctx.user.id, ctx.user.email);
    } catch {
      // A failed promotion must not break the gate — fall through to the role.
    }
    const isAdmin = await admin.isAdminUser(ctx.user.id);
    return { isAdmin, email: ctx.user.email, role: isAdmin ? "admin" : ctx.user.role };
  }),

  stats: adminProcedure.query(() => admin.getStats()),

  users: adminProcedure
    .input(z.object({ limit: z.number().int().min(1).max(1000).default(500) }).optional())
    .query(({ input }) => admin.listUsers(input?.limit ?? 500)),

  sessions: adminProcedure
    .input(z.object({ limit: z.number().int().min(1).max(1000).default(300) }).optional())
    .query(({ input }) => admin.listSessions(input?.limit ?? 300)),

  referrals: adminProcedure.query(() => admin.listReferrals()),

  ledger: adminProcedure.query(() => admin.listLedger()),

  suspendUser: adminProcedure
    .input(z.object({ userId: z.uuid(), suspended: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      // An admin locking themselves out is never what they meant.
      if (input.userId === ctx.user.id && input.suspended) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "You cannot suspend your own account." });
      }
      try {
        return await admin.setUserSuspended(input.userId, input.suspended);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  settings: adminProcedure.query(() => q.getSettings()),

  saveSettings: adminProcedure.input(settingsInput).mutation(async ({ input }) => {
    const next: SiteSettings = { ...DEFAULT_SETTINGS, ...input };
    return admin.saveSettings(next);
  }),

  tasks: adminProcedure.query(() => admin.listTasks()),

  createTask: adminProcedure
    .input(
      z.object({
        title: z.string().min(1).max(120),
        body: z.string().max(2000).default(""),
        kind: taskKind.default("task"),
        active: z.boolean().default(true),
        sortOrder: z.number().int().min(-999).max(999).default(0),
      }),
    )
    .mutation(async ({ input }) => {
      try {
        return await admin.createTask(input as { title: string; body: string; kind: TaskKind; active: boolean; sortOrder: number });
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  updateTask: adminProcedure
    .input(
      z.object({
        id: z.uuid(),
        title: z.string().min(1).max(120).optional(),
        body: z.string().max(2000).optional(),
        kind: taskKind.optional(),
        active: z.boolean().optional(),
        sortOrder: z.number().int().min(-999).max(999).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, ...patch } = input;
      try {
        return await admin.updateTask(id, patch);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  deleteTask: adminProcedure
    .input(z.object({ id: z.uuid() }))
    .mutation(async ({ input }) => {
      try {
        return await admin.deleteTask(input.id);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  // ── daily tasks ──
  dailyTasks: adminProcedure.query(() => daily.listDailyTasks()),

  createDailyTask: adminProcedure
    .input(
      z.object({
        title: z.string().min(1).max(120),
        body: z.string().max(2000).default(""),
        reward: z.number().min(0).max(10).default(0.01),
        active: z.boolean().default(true),
        sortOrder: z.number().int().min(-999).max(999).default(0),
      }),
    )
    .mutation(async ({ input }) => {
      try {
        return await daily.createDailyTask(input);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  updateDailyTask: adminProcedure
    .input(
      z.object({
        id: z.uuid(),
        title: z.string().min(1).max(120).optional(),
        body: z.string().max(2000).optional(),
        reward: z.number().min(0).max(10).optional(),
        active: z.boolean().optional(),
        sortOrder: z.number().int().min(-999).max(999).optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const { id, ...patch } = input;
      try {
        return await daily.updateDailyTask(id, patch);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  deleteDailyTask: adminProcedure
    .input(z.object({ id: z.uuid() }))
    .mutation(async ({ input }) => {
      try {
        return await daily.deleteDailyTask(input.id);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),

  /** Self-service password change — the owner never needs a code edit for this. */
  changePassword: adminProcedure
    .input(
      z.object({
        currentPassword: z.string().min(1),
        newPassword: z.string().min(8, "The new password must be at least 8 characters."),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      try {
        return await admin.changeOwnPassword(ctx.user.id, input.currentPassword, input.newPassword);
      } catch (e) {
        asAdminTrpc(e);
      }
    }),
});

// Sanitize a caller-supplied filename down to a safe key BASENAME: take the
// last path segment (so "/../shared/report.pdf" can't steer the rest of the
// key), keep only [A-Za-z0-9._-], strip leading dots (so a survivor of "." or
// ".." can't slip through as a bare segment), and fall back to a fixed constant
// when nothing survives. Exported so it can be unit-tested directly.
//
// The stem and the extension are sanitized SEPARATELY, and that split is the
// whole point. Sanitizing the basename as one string used to destroy the
// extension of any file whose stem was entirely non-ASCII: the allowlist below
// deleted every CJK character in "风景.png", leaving ".png", and the leading-dot
// strip — there to kill "." / ".." / dotfiles — then ate the extension
// separator, because by that point it was the only dot left. The object landed
// in storage as "<uuid>-png". Splitting first means the leading-dot rule only
// ever sees the stem, where a leading dot really is a dotfile prefix.
export function sanitizeBasename(name: string): string {
  // Split on "\\" too: it cannot steer a path segment (the key joins on "/"),
  // but a Windows path would otherwise fold its directories into the stem.
  const last = name.split(/[/\\]/).pop() ?? "";
  // `> 0`, not `>= 0`: in ".gitignore" the dot is a dotfile prefix, not an
  // extension separator, so the whole name is the stem.
  const dot = last.lastIndexOf(".");
  const rawStem = dot > 0 ? last.slice(0, dot) : last;
  const rawExt = dot > 0 ? last.slice(dot + 1) : "";
  const stem =
    rawStem.replace(/[^A-Za-z0-9._-]/g, "").replace(/^\.+/, "") || "upload";
  // No dots or separators in an extension, and capped — the key is
  // `${uuid}-${basename}`, so a long tail buys nothing.
  const ext = rawExt.replace(/[^A-Za-z0-9]/g, "").slice(0, 10);
  return ext ? `${stem}.${ext}` : stem;
}

// Example file-upload router. The three-step protocol matters: the browser PUTs
// straight to object storage, so the server only learns the upload succeeded when
// the client calls `commit`. Skipping commit leaves an unindexed orphan object —
// never a row pointing at nothing.
//
//   1. uploadUrl  → signed PUT URL + the key to commit later
//   2. browser    → PUT the bytes to uploadUrl
//   3. commit     → index it (size/type are read back from storage)
const filesRouter = router({
  uploadUrl: protectedProcedure
    .input(z.object({ name: z.string().min(1), contentType: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      // The uuid prefix makes the key unguessable ONLY if the rest of the key
      // isn't attacker-controlled — sanitizeBasename strips the client-supplied
      // `name` down to a safe basename first, so it can't steer path segments
      // (e.g. "/../report.pdf") into someone else's key.
      const key = `${crypto.randomUUID()}-${sanitizeBasename(input.name)}`;
      try {
        const { uploadUrl, publicPath } = await storagePutUrl(key, input.contentType, {
          ownerId: ctx.user.id,
        });
        return { key, uploadUrl, publicPath };
      } catch (e) {
        if (e instanceof StorageError && e.code === "failed") {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              "upload rejected by storage — check contentType is on the platform's whitelist " +
              "(see AGENT.md: png/jpeg/gif/webp/avif, pdf, text/plain, csv, json, mpeg/wav audio, mp4/webm video)",
          });
        }
        throw e;
      }
    }),

  commit: protectedProcedure
    .input(z.object({ key: z.string().min(1), name: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      try {
        return await storageCommit(input.key, { ownerId: ctx.user.id, name: input.name });
      } catch (e) {
        if (e instanceof StorageError && e.code === "not_found") {
          throw new TRPCError({ code: "NOT_FOUND", message: "upload not found — did the PUT succeed?" });
        }
        if (e instanceof StorageError && e.code === "forbidden") {
          throw new TRPCError({ code: "FORBIDDEN", message: "that key belongs to another user" });
        }
        throw e;
      }
    }),

  list: protectedProcedure.query(({ ctx }) => storageListByOwner(ctx.user.id)),

  remove: protectedProcedure
    .input(z.object({ key: z.string().min(1) }))
    .mutation(async ({ ctx, input }) => {
      try {
        return await storageDeleteOwned(ctx.user.id, input.key);
      } catch (e) {
        if (e instanceof StorageError && e.code === "forbidden") {
          throw new TRPCError({ code: "BAD_REQUEST", message: "malformed key" });
        }
        throw e;
      }
    }),
});

export const appRouter = router({
  auth: authRouter,
  mining: miningRouter,
  daily: dailyRouter,
  admin: adminRouter,
  files: filesRouter,
});

export type AppRouter = typeof appRouter;
