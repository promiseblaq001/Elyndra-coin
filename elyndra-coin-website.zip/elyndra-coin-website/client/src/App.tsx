import { Route, Switch } from "wouter";
import Protected from "./_core/Protected";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Mine from "./pages/Mine";
import Team from "./pages/Team";
import Wallet from "./pages/Wallet";
import Profile from "./pages/Profile";
import Daily from "./pages/Daily";
import Admin from "./pages/Admin";
import AdminLogin from "./pages/AdminLogin";

// Agent wires business routes here (wouter).
export default function App() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/mine">
        <Protected>
          <Mine />
        </Protected>
      </Route>
      <Route path="/team">
        <Protected>
          <Team />
        </Protected>
      </Route>
      <Route path="/wallet">
        <Protected>
          <Wallet />
        </Protected>
      </Route>
      <Route path="/daily">
        <Protected>
          <Daily />
        </Protected>
      </Route>
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin">
        <Protected>
          <Admin />
        </Protected>
      </Route>
      <Route path="/profile">
        <Protected>
          <Profile />
        </Protected>
      </Route>
      <Route>{() => <div className="p-8">Not found</div>}</Route>
    </Switch>
  );
}
