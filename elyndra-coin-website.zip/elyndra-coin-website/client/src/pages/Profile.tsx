import { useState, type FormEvent } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/_core/trpc";
import { useAuth } from "@/_core/useAuth";
import {
  Shell,
  TabBar,
  PageHeader,
  Eyebrow,
  PanelSkeleton,
  ErrorPanel,
  SimulationNotice,
} from "@/components/ely";
import { formatEly } from "@shared/mining";

export default function Profile() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const status = trpc.mining.status.useQuery();
  const setUsername = trpc.mining.setUsername.useMutation({
    onSuccess: () => utils.mining.status.invalidate(),
  });

  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState<string | null>(null);

  async function onSave(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    try {
      await setUsername.mutateAsync({ username: draft });
      setEditing(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save");
    }
  }

  async function onLogout() {
    await logout();
    navigate("/");
  }

  return (
    <>
      <Shell>
        <PageHeader title="You" subtitle="Your account and mining identity." />

        {status.isLoading && <PanelSkeleton lines={4} />}
        {status.isError && (
          <ErrorPanel message={status.error.message} onRetry={() => void status.refetch()} />
        )}

        {status.data && (
          <div className="ely-rise space-y-6">
            <section className="ely-panel px-4 py-4">
              <Eyebrow>Username</Eyebrow>
              {editing ? (
                <form onSubmit={onSave} className="mt-2 space-y-2.5">
                  <input
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    autoFocus
                    maxLength={20}
                    className="h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-jade/60"
                    placeholder="3–20 letters, numbers, underscores"
                  />
                  {error && <p className="text-xs text-destructive">{error}</p>}
                  <div className="flex gap-2">
                    <button
                      type="submit"
                      disabled={setUsername.isPending}
                      className="h-9 flex-1 rounded-full bg-jade text-xs font-semibold text-[#04140f] disabled:opacity-60"
                    >
                      {setUsername.isPending ? "Saving…" : "Save"}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditing(false);
                        setError(null);
                      }}
                      className="h-9 flex-1 rounded-full border border-border text-xs font-medium text-muted-foreground"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <div className="mt-1.5 flex items-center justify-between gap-3">
                  <span className="ely-display text-xl text-foreground">
                    @{status.data.profile.username}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setDraft(status.data!.profile.username);
                      setEditing(true);
                    }}
                    className="shrink-0 rounded-full border border-border px-3 py-1.5 text-[0.7rem] font-medium text-muted-foreground transition-colors hover:border-jade/40 hover:text-foreground"
                  >
                    Change
                  </button>
                </div>
              )}
            </section>

            <section className="ely-panel divide-y divide-border/70">
              <Field label="Email" value={user?.email ?? "—"} />
              <Field label="Referral code" value={status.data.profile.referralCode} mono />
              <Field label="Balance" value={`${formatEly(status.data.profile.balance, 4)} ELY`} mono />
              <Field
                label="Member since"
                value={new Date(status.data.profile.createdAt).toLocaleDateString(undefined, {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              />
            </section>

            <SimulationNotice />

            <button
              type="button"
              onClick={() => void onLogout()}
              className="h-11 w-full rounded-full border border-border text-sm font-medium text-muted-foreground transition-colors hover:border-destructive/40 hover:text-destructive"
            >
              Log out
            </button>
          </div>
        )}
      </Shell>
      <TabBar />
    </>
  );
}

function Field({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-4 px-4 py-3.5">
      <span className="shrink-0 text-xs text-muted-foreground">{label}</span>
      <span
        className={
          mono
            ? "ely-num truncate text-sm text-foreground"
            : "truncate text-sm text-foreground"
        }
      >
        {value}
      </span>
    </div>
  );
}
