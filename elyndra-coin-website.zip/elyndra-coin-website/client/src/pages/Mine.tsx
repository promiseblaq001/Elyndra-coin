import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/_core/trpc";
import {
  Shell,
  TabBar,
  Eyebrow,
  Stat,
  PanelSkeleton,
  ErrorPanel,
  SimulationNotice,
} from "@/components/ely";
import { MiningOrb, useServerClock } from "@/components/mining-orb";
import { formatEly, MAX_BOOST_MEMBERS } from "@shared/mining";

export default function Mine() {
  const utils = trpc.useUtils();
  const status = trpc.mining.status.useQuery(undefined, {
    // Poll so a session that ends while the screen is open flips to "Claim".
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });

  const start = trpc.mining.start.useMutation({
    onSuccess: () => utils.mining.status.invalidate(),
  });
  const claim = trpc.mining.claim.useMutation({
    onSuccess: () => {
      utils.mining.status.invalidate();
      utils.mining.ledger.invalidate();
    },
  });

  const [notice, setNotice] = useState<string | null>(null);
  const now = useServerClock(status.data?.serverNow);

  const busy = start.isPending || claim.isPending;
  const error = start.error ?? claim.error;

  async function onStart() {
    setNotice(null);
    try {
      await start.mutateAsync();
    } catch {
      /* surfaced below */
    }
  }

  async function onClaim() {
    setNotice(null);
    try {
      const res = await claim.mutateAsync();
      setNotice(`Claimed ${formatEly(res.amount, 4)} ELY. Tap again to open your next session.`);
    } catch {
      /* surfaced below */
    }
  }

  return (
    <>
      <Shell>
        <header className="mb-6 flex items-start justify-between">
          <div>
            <Eyebrow>Mining</Eyebrow>
            <h1 className="ely-display mt-1 text-2xl text-foreground">
              {status.data ? `@${status.data.profile.username}` : "Your session"}
            </h1>
          </div>
          <Link
            to="/wallet"
            className="rounded-full border border-border px-3 py-1.5 text-[0.7rem] font-medium text-muted-foreground transition-colors hover:border-gold/40 hover:text-foreground"
          >
            Wallet
          </Link>
        </header>

        {status.isLoading && <PanelSkeleton lines={4} />}

        {status.isError && (
          <ErrorPanel
            message={status.error.message}
            onRetry={() => void status.refetch()}
          />
        )}

        {status.data && (
          <div className="ely-rise space-y-6">
            {status.data.announcement && (
              <div className="rounded-lg border border-gold/25 bg-gold/[0.05] px-3.5 py-3">
                <p className="text-[0.7rem] font-medium uppercase tracking-[0.16em] text-gold">From the network</p>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  {status.data.announcement}
                </p>
              </div>
            )}

            {status.data.suspended && (
              <div className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-3">
                <p className="text-xs font-medium text-destructive">Account suspended</p>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                  You can still claim a finished session, but you cannot open a new one. Contact the
                  network admin.
                </p>
              </div>
            )}

            <MiningOrb
              session={status.data.session}
              now={now}
              onStart={onStart}
              onClaim={onClaim}
              busy={busy}
            />

            {notice && (
              <p className="rounded-lg border border-jade/25 bg-jade/[0.06] px-3.5 py-2.5 text-center text-xs leading-relaxed text-jade">
                {notice}
              </p>
            )}

            {error && (
              <p className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-2.5 text-center text-xs leading-relaxed text-destructive">
                {error.message}
              </p>
            )}

            {/* Rate breakdown — where the number on the orb comes from. */}
            <section>
              <Eyebrow>Your rate</Eyebrow>
              <div className="mt-2.5 grid grid-cols-2 gap-2.5">
                <Stat
                  label="Base"
                  value={`${formatEly(status.data.rates.base, 4)}`}
                  hint="ELY per hour"
                />
                <Stat
                  label="Circle boost"
                  value={`+${formatEly(status.data.rates.boost, 4)}`}
                  hint={`${status.data.rates.activeMembers} of ${MAX_BOOST_MEMBERS} active`}
                  accent="gold"
                />
              </div>
              <div className="ely-panel mt-2.5 flex items-baseline justify-between px-4 py-3.5">
                <span className="text-xs text-muted-foreground">Total rate</span>
                <span className="ely-num text-lg text-jade">
                  {formatEly(status.data.rates.total, 4)}{" "}
                  <span className="text-[0.7rem] tracking-widest text-muted-foreground">ELY/hr</span>
                </span>
              </div>
              <p className="mt-2.5 text-[0.7rem] leading-relaxed text-muted-foreground">
                {status.data.session
                  ? "These rates are locked for the current session."
                  : "These are the rates your next session will start with."}
              </p>
            </section>

            {/* Balance + circle summary */}
            <section className="grid grid-cols-2 gap-2.5">
              <Stat
                label="Balance"
                value={formatEly(status.data.profile.balance, 4)}
                hint="Claimed ELY"
                accent="jade"
              />
              <Stat
                label="Security Circle"
                value={`${status.data.team.active}/${status.data.team.total}`}
                hint="active / invited"
              />
            </section>

            <Link
              to="/team"
              className="flex items-center justify-between rounded-lg border border-border px-4 py-3.5 transition-colors hover:border-gold/40"
            >
              <div>
                <p className="text-sm font-medium text-foreground">Grow your circle</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Each active member adds {formatEly(status.data.rates.boost > 0 ? status.data.rates.boost / Math.max(1, status.data.rates.activeMembers) : 0.0025, 4)} ELY/hr
                </p>
              </div>
              <span className="text-gold">→</span>
            </Link>

            <Link
              to="/daily"
              className="flex items-center justify-between rounded-lg border border-border px-4 py-3.5 transition-colors hover:border-jade/40"
            >
              <div>
                <p className="text-sm font-medium text-foreground">Today&apos;s tasks</p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Small daily tasks, each with an ELY reward
                </p>
              </div>
              <span className="text-jade">→</span>
            </Link>

            <SimulationNotice compact />
          </div>
        )}
      </Shell>
      <TabBar />
    </>
  );
}
