import { useState, type FormEvent } from "react";
import { Link, Redirect } from "wouter";
import { useAuth } from "@/_core/useAuth";
import { Shell, Wordmark, Eyebrow } from "@/components/ely";

export default function Login() {
  const { login, user } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await login(email, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setBusy(false);
    }
  }

  // Declarative, not `navigate()` straight after the await. The auth query's
  // cache update and this component's re-render are not the same tick, so an
  // imperative jump reaches the guarded route while `user` is still null, and
  // <Protected> bounces it right back here.
  if (user) return <Redirect to="/mine" />;

  return (
    <Shell className="justify-center pb-14">
      <div className="mb-10">
        <Wordmark size="lg" />
        <p className="mt-3 text-sm text-muted-foreground">Welcome back to the network.</p>
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Eyebrow>Email</Eyebrow>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-jade/60"
            placeholder="you@example.com"
          />
        </div>
        <div className="space-y-1.5">
          <Eyebrow>Password</Eyebrow>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-jade/60"
            placeholder="••••••••"
          />
        </div>

        {error && (
          <p className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-2.5 text-xs leading-relaxed text-destructive">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="h-12 w-full rounded-full bg-jade text-sm font-semibold text-[#04140f] transition-all hover:brightness-105 disabled:opacity-60"
        >
          {busy ? "Logging in…" : "Log in"}
        </button>
      </form>

      <p className="mt-6 text-center text-xs text-muted-foreground">
        No account?{" "}
        <Link to="/register" className="font-medium text-jade underline underline-offset-4">
          Create one
        </Link>
      </p>
      <p className="mt-8 text-center text-[0.7rem] text-muted-foreground/70">
        <Link to="/" className="hover:text-foreground">
          ← Back to Elyndra
        </Link>
      </p>
    </Shell>
  );
}
