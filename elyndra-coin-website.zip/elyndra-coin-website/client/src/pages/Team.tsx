import { useState } from "react";
import { trpc } from "@/_core/trpc";
import { publicUrl } from "@/_core/public-url";
import {
  Shell,
  TabBar,
  PageHeader,
  Eyebrow,
  Stat,
  EmptyState,
  PanelSkeleton,
  ErrorPanel,
  SimulationNotice,
} from "@/components/ely";
import { formatEly, MAX_BOOST_MEMBERS } from "@shared/mining";

export default function Team() {
  const team = trpc.mining.team.useQuery();
  const [copied, setCopied] = useState<"code" | "link" | null>(null);

  const link = team.data ? publicUrl(`/register?ref=${team.data.referralCode}`) : "";

  async function copy(value: string, which: "code" | "link") {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(which);
      window.setTimeout(() => setCopied(null), 1800);
    } catch {
      setCopied(null);
    }
  }

  return (
    <>
      <Shell>
        <PageHeader
          title="Security Circle"
          subtitle="People you invited. Each one who starts mining adds to your rate."
        />

        {team.isLoading && <PanelSkeleton lines={4} />}
        {team.isError && (
          <ErrorPanel message={team.error.message} onRetry={() => void team.refetch()} />
        )}

        {team.data && (
          <div className="ely-rise space-y-6">
            {/* Invite card */}
            <section className="ely-panel overflow-hidden">
              <div className="border-b border-border/70 px-4 py-4">
                <Eyebrow>Your referral code</Eyebrow>
                <div className="mt-2 flex items-center justify-between gap-3">
                  <span className="ely-num text-3xl tracking-[0.18em] text-gold">
                    {team.data.referralCode}
                  </span>
                  <button
                    type="button"
                    onClick={() => void copy(team.data!.referralCode, "code")}
                    className="shrink-0 rounded-full border border-border px-3 py-1.5 text-[0.7rem] font-medium text-muted-foreground transition-colors hover:border-gold/40 hover:text-foreground"
                  >
                    {copied === "code" ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>

              <div className="px-4 py-4">
                <Eyebrow>Invite link</Eyebrow>
                <p className="mt-2 break-all rounded-lg border border-border bg-background/60 px-3 py-2.5 text-[0.7rem] leading-relaxed text-muted-foreground">
                  {link}
                </p>
                <button
                  type="button"
                  onClick={() => void copy(link, "link")}
                  className="mt-2.5 h-10 w-full rounded-full bg-jade text-xs font-semibold text-[#04140f] transition-all hover:brightness-105"
                >
                  {copied === "link" ? "Link copied" : "Copy invite link"}
                </button>
                <p className="mt-2.5 text-[0.7rem] leading-relaxed text-muted-foreground">
                  They join your circle the moment they sign up with this link, and start counting
                  toward your boost once they open their first session.
                </p>
              </div>
            </section>

            {/* Boost summary */}
            <section className="grid grid-cols-2 gap-2.5">
              <Stat
                label="Active members"
                value={`${team.data.activeMembers}/${MAX_BOOST_MEMBERS}`}
                hint="counted toward boost"
                accent="jade"
              />
              <Stat
                label="Boost earned"
                value={`+${formatEly(team.data.boostRate, 4)}`}
                hint="ELY per hour"
                accent="gold"
              />
            </section>

            <p className="text-[0.7rem] leading-relaxed text-muted-foreground">
              The boost is capped at {MAX_BOOST_MEMBERS} active members. You also earn a one-time{" "}
              {formatEly(team.data.bonusPerReferral, 2)} ELY when a member claims their first
              session.
            </p>

            {/* Member list */}
            <section>
              <div className="mb-2.5 flex items-baseline justify-between">
                <Eyebrow>Members</Eyebrow>
                <span className="text-[0.7rem] text-muted-foreground">
                  {team.data.members.length} invited
                </span>
              </div>

              {team.data.members.length === 0 ? (
                <EmptyState
                  title="No one in your circle yet"
                  body="Share your code or invite link. A member appears here as soon as they sign up, and starts boosting your rate once they begin mining."
                />
              ) : (
                <ul className="ely-panel divide-y divide-border/70">
                  {team.data.members.map((m) => (
                    <li key={m.username} className="flex items-center justify-between px-4 py-3.5">
                      <div className="min-w-0">
                        <p className="truncate text-sm text-foreground">@{m.username}</p>
                        <p className="mt-0.5 text-[0.7rem] text-muted-foreground">
                          joined {new Date(m.joinedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <span
                        className={
                          m.active
                            ? "shrink-0 rounded-full border border-jade/30 bg-jade/[0.08] px-2.5 py-1 text-[0.65rem] font-medium text-jade"
                            : "shrink-0 rounded-full border border-border px-2.5 py-1 text-[0.65rem] font-medium text-muted-foreground"
                        }
                      >
                        {m.active ? "Active" : "Not mining"}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <SimulationNotice compact />
          </div>
        )}
      </Shell>
      <TabBar />
    </>
  );
}
