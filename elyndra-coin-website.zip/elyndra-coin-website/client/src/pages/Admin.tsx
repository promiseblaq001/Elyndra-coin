import { useState, type FormEvent, type ReactNode } from "react";
import { Link } from "wouter";
import { trpc } from "@/_core/trpc";
import { useAuth } from "@/_core/useAuth";
import { Wordmark, Eyebrow, PanelSkeleton, ErrorPanel, EmptyState } from "@/components/ely";
import { formatEly } from "@shared/mining";
import { cn } from "@/lib/utils";

/**
 * The admin console. Deliberately NOT inside the 480px miner shell: an operator
 * reading a table of every session needs the width. It keeps the same palette
 * so it still reads as the same product.
 *
 * Access is enforced twice: this component refuses to render for a non-admin,
 * and every procedure it calls is an `adminProcedure` on the server — so the
 * gate holds even if someone reaches the URL directly.
 */
export default function Admin() {
  const { user, isLoading } = useAuth();
  const whoami = trpc.admin.whoami.useQuery(undefined, { enabled: Boolean(user) });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-6xl px-5 py-10">
        <PanelSkeleton lines={4} />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="mx-auto max-w-md px-5 py-16 text-center">
        <Wordmark size="lg" />
        <p className="mt-4 text-sm text-muted-foreground">Sign in with an admin account to open the console.</p>
        <Link
          to="/admin/login"
          className="mt-6 inline-flex h-11 items-center justify-center rounded-full bg-gold px-6 text-sm font-semibold text-[#1a1405]"
        >
          Admin sign-in
        </Link>
      </div>
    );
  }

  if (whoami.isLoading) {
    return (
      <div className="mx-auto max-w-6xl px-5 py-10">
        <PanelSkeleton lines={3} />
      </div>
    );
  }

  if (!whoami.data?.isAdmin) {
    return (
      <div className="mx-auto max-w-md px-5 py-16 text-center">
        <Wordmark size="lg" />
        <div className="mt-6 rounded-lg border border-destructive/30 bg-destructive/[0.06] px-4 py-4 text-left">
          <p className="text-sm font-medium text-destructive">Not an admin account</p>
          <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
            You are signed in as <span className="text-foreground">{whoami.data?.email}</span>, which has the
            role <span className="ely-num text-foreground">{whoami.data?.role}</span>. The console is limited
            to accounts with the admin role.
          </p>
        </div>
        <Link to="/mine" className="mt-6 inline-flex text-xs font-medium text-jade underline underline-offset-4">
          ← Back to mining
        </Link>
      </div>
    );
  }

  return <Console email={whoami.data.email} />;
}

type Tab = "overview" | "users" | "sessions" | "referrals" | "tasks" | "daily" | "settings" | "security";

const TABS: { id: Tab; label: string }[] = [
  { id: "overview", label: "Overview" },
  { id: "users", label: "Users" },
  { id: "sessions", label: "Sessions" },
  { id: "referrals", label: "Referrals" },
  { id: "tasks", label: "Tasks" },
  { id: "daily", label: "Daily tasks" },
  { id: "settings", label: "Settings" },
  { id: "security", label: "Security" },
];

function Console({ email }: { email: string }) {
  const [tab, setTab] = useState<Tab>("overview");

  return (
    <div className="mx-auto max-w-6xl px-4 pb-20 pt-6 sm:px-6">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border pb-4">
        <div className="flex items-baseline gap-3">
          <Wordmark />
          <span className="rounded-full border border-gold/30 bg-gold/[0.06] px-2.5 py-0.5 text-[0.6rem] font-medium uppercase tracking-[0.18em] text-gold">
            Admin
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden text-xs text-muted-foreground sm:inline">{email}</span>
          <Link
            to="/mine"
            className="rounded-full border border-border px-3 py-1.5 text-[0.7rem] font-medium text-muted-foreground transition-colors hover:border-jade/40 hover:text-foreground"
          >
            Miner view
          </Link>
        </div>
      </header>

      <nav className="mt-4 flex gap-1 overflow-x-auto pb-1">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors",
              tab === t.id
                ? "bg-jade text-[#04140f]"
                : "border border-border text-muted-foreground hover:text-foreground",
            )}
          >
            {t.label}
          </button>
        ))}
      </nav>

      <main className="mt-6">
        {tab === "overview" && <Overview />}
        {tab === "users" && <Users />}
        {tab === "sessions" && <Sessions />}
        {tab === "referrals" && <Referrals />}
        {tab === "tasks" && <Tasks />}
        {tab === "daily" && <DailyTasks />}
        {tab === "settings" && <Settings />}
        {tab === "security" && <Security email={email} />}
      </main>
    </div>
  );
}

// ── shared bits ───────────────────────────────────────────────────────────────

function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("ely-panel px-4 py-4", className)}>{children}</div>;
}

function Metric({ label, value, hint, accent }: { label: string; value: string; hint?: string; accent?: "jade" | "gold" }) {
  return (
    <Card>
      <Eyebrow>{label}</Eyebrow>
      <p
        className={cn(
          "ely-num mt-1.5 text-2xl leading-none",
          accent === "jade" && "text-jade",
          accent === "gold" && "text-gold",
          !accent && "text-foreground",
        )}
      >
        {value}
      </p>
      {hint && <p className="mt-1.5 text-[0.7rem] leading-snug text-muted-foreground">{hint}</p>}
    </Card>
  );
}

function Table({ head, children }: { head: string[]; children: ReactNode }) {
  return (
    <div className="ely-panel overflow-x-auto">
      <table className="w-full min-w-[640px] text-left text-xs">
        <thead>
          <tr className="border-b border-border">
            {head.map((h) => (
              <th key={h} className="whitespace-nowrap px-3.5 py-2.5 font-medium uppercase tracking-[0.12em] text-[0.6rem] text-muted-foreground">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-border/60">{children}</tbody>
      </table>
    </div>
  );
}

function Td({ children, mono, muted }: { children: ReactNode; mono?: boolean; muted?: boolean }) {
  return (
    <td className={cn("whitespace-nowrap px-3.5 py-2.5", mono && "ely-num", muted ? "text-muted-foreground" : "text-foreground")}>
      {children}
    </td>
  );
}

function Badge({ children, tone }: { children: ReactNode; tone: "jade" | "gold" | "muted" | "danger" }) {
  return (
    <span
      className={cn(
        "inline-flex rounded-full border px-2 py-0.5 text-[0.6rem] font-medium",
        tone === "jade" && "border-jade/30 bg-jade/[0.08] text-jade",
        tone === "gold" && "border-gold/30 bg-gold/[0.08] text-gold",
        tone === "muted" && "border-border text-muted-foreground",
        tone === "danger" && "border-destructive/30 bg-destructive/[0.08] text-destructive",
      )}
    >
      {children}
    </span>
  );
}

function fmtDate(iso: string) {
  return new Date(iso).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ── overview ──────────────────────────────────────────────────────────────────

function Overview() {
  const stats = trpc.admin.stats.useQuery();
  const ledger = trpc.admin.ledger.useQuery();

  if (stats.isLoading) return <PanelSkeleton lines={4} />;
  if (stats.isError) return <ErrorPanel message={stats.error.message} onRetry={() => void stats.refetch()} />;
  if (!stats.data) return null;

  const s = stats.data;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric label="Accounts" value={String(s.totalUsers)} hint={`${s.newUsersToday} joined today`} accent="jade" />
        <Metric label="Open sessions" value={String(s.activeSessions)} hint="mining right now" />
        <Metric label="Total mined" value={formatEly(s.totalMined, 4)} hint="ELY across all accounts" accent="gold" />
        <Metric label="Circulating" value={formatEly(s.totalBalance, 4)} hint="sum of balances" />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric label="Suspended" value={String(s.suspendedUsers)} hint="blocked from new sessions" />
        <Metric label="Published tasks" value={String(s.activeTasks)} hint="visible to miners" />
      </div>

      <section>
        <Eyebrow>Recent ledger activity</Eyebrow>
        <div className="mt-2.5">
          {ledger.isLoading && <PanelSkeleton lines={3} />}
          {ledger.data && ledger.data.length === 0 && (
            <EmptyState
              title="No credits yet"
              body="Every mining claim, referral bonus and daily-task reward lands here. Nothing has been credited so far."
            />
          )}
          {ledger.data && ledger.data.length > 0 && (
            <Table head={["Miner", "Amount", "Type", "Note", "When"]}>
              {ledger.data.slice(0, 25).map((r) => (
                <tr key={r.id}>
                  <Td>@{r.username}</Td>
                  <Td mono>{formatEly(r.amount, 4)}</Td>
                  <Td muted>{r.type.replace(/_/g, " ")}</Td>
                  <Td muted>{r.note ?? "—"}</Td>
                  <Td muted>{fmtDate(r.createdAt)}</Td>
                </tr>
              ))}
            </Table>
          )}
        </div>
      </section>
    </div>
  );
}

// ── users ────────────────────────────────────────────────────────────────────

function Users() {
  const utils = trpc.useUtils();
  const users = trpc.admin.users.useQuery({ limit: 500 });
  const suspend = trpc.admin.suspendUser.useMutation({
    onSuccess: () => {
      void utils.admin.users.invalidate();
      void utils.admin.stats.invalidate();
    },
  });
  const [q, setQ] = useState("");

  if (users.isLoading) return <PanelSkeleton lines={5} />;
  if (users.isError) return <ErrorPanel message={users.error.message} onRetry={() => void users.refetch()} />;

  const rows = (users.data ?? []).filter((u) => {
    const needle = q.trim().toLowerCase();
    if (!needle) return true;
    return u.email.toLowerCase().includes(needle) || u.username.toLowerCase().includes(needle);
  });

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Eyebrow>{users.data?.length ?? 0} registered accounts</Eyebrow>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Filter by email or username"
          className="h-9 w-full max-w-xs rounded-lg border border-input bg-panel px-3 text-xs text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-jade/60"
        />
      </div>

      {rows.length === 0 ? (
        <EmptyState
          title={q ? "No match" : "No accounts yet"}
          body={
            q
              ? "No account matches that filter. Clear it to see everyone."
              : "Nobody has signed up yet. Accounts appear here the moment someone registers."
          }
        />
      ) : (
        <Table head={["Miner", "Email", "Balance", "Total mined", "Circle", "Role", "Joined", ""]}>
          {rows.map((u) => (
            <tr key={u.userId}>
              <Td>
                <span className="flex items-center gap-2">
                  @{u.username}
                  {u.suspended && <Badge tone="danger">suspended</Badge>}
                </span>
              </Td>
              <Td muted>{u.email}</Td>
              <Td mono>{formatEly(u.balance, 4)}</Td>
              <Td mono muted>{formatEly(u.totalMined, 4)}</Td>
              <Td muted>
                {u.circleActive}/{u.circleTotal}
              </Td>
              <Td>{u.role === "admin" ? <Badge tone="gold">admin</Badge> : <span className="text-muted-foreground">user</span>}</Td>
              <Td muted>{fmtDate(u.createdAt)}</Td>
              <Td>
                <button
                  type="button"
                  disabled={suspend.isPending}
                  onClick={() => suspend.mutate({ userId: u.userId, suspended: !u.suspended })}
                  className={cn(
                    "rounded-full border px-2.5 py-1 text-[0.65rem] font-medium transition-colors disabled:opacity-50",
                    u.suspended
                      ? "border-jade/40 text-jade hover:bg-jade/10"
                      : "border-border text-muted-foreground hover:border-destructive/40 hover:text-destructive",
                  )}
                >
                  {u.suspended ? "Reinstate" : "Suspend"}
                </button>
              </Td>
            </tr>
          ))}
        </Table>
      )}

      {suspend.error && (
        <p className="text-xs text-destructive">{suspend.error.message}</p>
      )}
    </div>
  );
}

// ── sessions ─────────────────────────────────────────────────────────────────

function Sessions() {
  const sessions = trpc.admin.sessions.useQuery({ limit: 300 });
  const [filter, setFilter] = useState<"all" | "running" | "awaiting" | "claimed">("all");

  if (sessions.isLoading) return <PanelSkeleton lines={5} />;
  if (sessions.isError) return <ErrorPanel message={sessions.error.message} onRetry={() => void sessions.refetch()} />;

  const all = sessions.data ?? [];
  const rows = all.filter((s) => {
    if (filter === "running") return s.running;
    if (filter === "awaiting") return s.awaitingClaim;
    if (filter === "claimed") return s.claimed;
    return true;
  });

  const running = all.filter((s) => s.running).length;
  const awaiting = all.filter((s) => s.awaitingClaim).length;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Eyebrow>
          {all.length} sessions · {running} running · {awaiting} awaiting claim
        </Eyebrow>
        <div className="flex gap-1">
          {(["all", "running", "awaiting", "claimed"] as const).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFilter(f)}
              className={cn(
                "rounded-full px-2.5 py-1 text-[0.65rem] font-medium capitalize transition-colors",
                filter === f ? "bg-jade text-[#04140f]" : "border border-border text-muted-foreground hover:text-foreground",
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {rows.length === 0 ? (
        <EmptyState
          title="No sessions here"
          body={
            all.length === 0
              ? "No mining session has been opened yet. The first tap on the Mine screen creates one."
              : "No session matches this filter. Switch back to All to see every session."
          }
        />
      ) : (
        <Table head={["Miner", "Started", "Ends", "Base", "Boost", "Accrued", "Status"]}>
          {rows.map((s) => (
            <tr key={s.id}>
              <Td>@{s.username}</Td>
              <Td muted>{fmtDate(s.startedAt)}</Td>
              <Td muted>{fmtDate(s.endsAt)}</Td>
              <Td mono muted>{formatEly(s.baseRate, 4)}</Td>
              <Td mono muted>{s.boostRate > 0 ? `+${formatEly(s.boostRate, 4)}` : "—"}</Td>
              <Td mono>{formatEly(s.accrued, 4)}</Td>
              <Td>
                {s.claimed ? (
                  <Badge tone="muted">claimed</Badge>
                ) : s.running ? (
                  <Badge tone="jade">running</Badge>
                ) : (
                  <Badge tone="gold">awaiting claim</Badge>
                )}
              </Td>
            </tr>
          ))}
        </Table>
      )}
    </div>
  );
}

// ── referrals ────────────────────────────────────────────────────────────────

function Referrals() {
  const refs = trpc.admin.referrals.useQuery();

  if (refs.isLoading) return <PanelSkeleton lines={4} />;
  if (refs.isError) return <ErrorPanel message={refs.error.message} onRetry={() => void refs.refetch()} />;

  const rows = refs.data ?? [];
  if (rows.length === 0) {
    return (
      <EmptyState
        title="No referrals yet"
        body="When someone signs up with another miner's code, the edge appears here — with whether the invitee has started mining and whether the bonus was paid."
      />
    );
  }

  return (
    <Table head={["Referrer", "Invitee", "Circle", "Bonus", "Joined"]}>
      {rows.map((r) => (
        <tr key={r.id}>
          <Td>@{r.referrerUsername}</Td>
          <Td>@{r.refereeUsername}</Td>
          <Td>{r.active ? <Badge tone="jade">active</Badge> : <Badge tone="muted">not mining</Badge>}</Td>
          <Td>{r.bonusPaid ? <Badge tone="gold">paid</Badge> : <Badge tone="muted">pending</Badge>}</Td>
          <Td muted>{fmtDate(r.createdAt)}</Td>
        </tr>
      ))}
    </Table>
  );
}

// ── tasks (announcements) ────────────────────────────────────────────────────

function Tasks() {
  const utils = trpc.useUtils();
  const tasks = trpc.admin.tasks.useQuery();
  const create = trpc.admin.createTask.useMutation({ onSuccess: () => void utils.admin.tasks.invalidate() });
  const update = trpc.admin.updateTask.useMutation({ onSuccess: () => void utils.admin.tasks.invalidate() });
  const remove = trpc.admin.deleteTask.useMutation({ onSuccess: () => void utils.admin.tasks.invalidate() });

  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [kind, setKind] = useState<"task" | "announcement">("announcement");

  async function onCreate(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!title.trim()) return;
    await create.mutateAsync({ title: title.trim(), body: body.trim(), kind, active: true, sortOrder: 0 });
    setTitle("");
    setBody("");
  }

  return (
    <div className="space-y-5">
      <Card>
        <Eyebrow>Publish something to the network</Eyebrow>
        <form onSubmit={onCreate} className="mt-3 space-y-2.5">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            maxLength={120}
            placeholder="Title — e.g. “Network update: faster claims”"
            className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-jade/60"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={2000}
            rows={3}
            placeholder="Body — what miners should know. Optional."
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-jade/60"
          />
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value as "task" | "announcement")}
              className="h-9 rounded-lg border border-input bg-background px-2.5 text-xs text-foreground outline-none focus:border-jade/60"
            >
              <option value="announcement">Announcement</option>
              <option value="task">Task</option>
            </select>
            <button
              type="submit"
              disabled={create.isPending}
              className="h-9 rounded-full bg-jade px-4 text-xs font-semibold text-[#04140f] disabled:opacity-60"
            >
              {create.isPending ? "Publishing…" : "Publish"}
            </button>
            {create.error && <span className="text-xs text-destructive">{create.error.message}</span>}
          </div>
        </form>
      </Card>

      {tasks.isLoading && <PanelSkeleton lines={3} />}
      {tasks.data && tasks.data.length === 0 && (
        <EmptyState
          title="Nothing published"
          body="Announcements and tasks you publish appear on the mining screen for every signed-in miner. Publish the first one above."
        />
      )}
      {tasks.data && tasks.data.length > 0 && (
        <div className="space-y-2.5">
          {tasks.data.map((t) => (
            <Card key={t.id}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-medium text-foreground">{t.title}</p>
                    <Badge tone={t.kind === "announcement" ? "gold" : "jade"}>{t.kind}</Badge>
                    {t.active ? <Badge tone="jade">live</Badge> : <Badge tone="muted">hidden</Badge>}
                  </div>
                  {t.body && <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{t.body}</p>}
                  <p className="mt-1.5 text-[0.65rem] text-muted-foreground/70">Updated {fmtDate(t.updatedAt)}</p>
                </div>
                <div className="flex shrink-0 gap-1.5">
                  <button
                    type="button"
                    onClick={() => update.mutate({ id: t.id, active: !t.active })}
                    className="rounded-full border border-border px-2.5 py-1 text-[0.65rem] font-medium text-muted-foreground hover:text-foreground"
                  >
                    {t.active ? "Hide" : "Publish"}
                  </button>
                  <button
                    type="button"
                    onClick={() => remove.mutate({ id: t.id })}
                    className="rounded-full border border-border px-2.5 py-1 text-[0.65rem] font-medium text-muted-foreground hover:border-destructive/40 hover:text-destructive"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ── daily tasks ──────────────────────────────────────────────────────────────

function DailyTasks() {
  const utils = trpc.useUtils();
  const tasks = trpc.admin.dailyTasks.useQuery();
  const create = trpc.admin.createDailyTask.useMutation({ onSuccess: () => void utils.admin.dailyTasks.invalidate() });
  const update = trpc.admin.updateDailyTask.useMutation({ onSuccess: () => void utils.admin.dailyTasks.invalidate() });
  const remove = trpc.admin.deleteDailyTask.useMutation({ onSuccess: () => void utils.admin.dailyTasks.invalidate() });

  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [reward, setReward] = useState("0.01");

  async function onCreate(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!title.trim()) return;
    const r = Number(reward);
    await create.mutateAsync({
      title: title.trim(),
      body: body.trim(),
      reward: Number.isFinite(r) ? r : 0.01,
      active: true,
      sortOrder: 0,
    });
    setTitle("");
    setBody("");
    setReward("0.01");
  }

  return (
    <div className="space-y-5">
      <Card>
        <Eyebrow>Add a daily task</Eyebrow>
        <p className="mt-1.5 text-[0.7rem] leading-relaxed text-muted-foreground">
          Miners can complete each task once per UTC day. The reward is credited to their balance and
          recorded in the ledger.
        </p>
        <form onSubmit={onCreate} className="mt-3 space-y-2.5">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            maxLength={120}
            placeholder="Title — e.g. “Open your mining session”"
            className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-jade/60"
          />
          <textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            maxLength={2000}
            rows={2}
            placeholder="What the miner should do. Optional."
            className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground/60 focus:border-jade/60"
          />
          <div className="flex flex-wrap items-center gap-2">
            <label className="flex items-center gap-1.5 text-xs text-muted-foreground">
              Reward
              <input
                value={reward}
                onChange={(e) => setReward(e.target.value)}
                inputMode="decimal"
                className="ely-num h-9 w-20 rounded-lg border border-input bg-background px-2 text-xs text-foreground outline-none focus:border-jade/60"
              />
              ELY
            </label>
            <button
              type="submit"
              disabled={create.isPending}
              className="h-9 rounded-full bg-jade px-4 text-xs font-semibold text-[#04140f] disabled:opacity-60"
            >
              {create.isPending ? "Adding…" : "Add task"}
            </button>
            {create.error && <span className="text-xs text-destructive">{create.error.message}</span>}
          </div>
        </form>
      </Card>

      {tasks.isLoading && <PanelSkeleton lines={3} />}
      {tasks.data && tasks.data.length === 0 && (
        <EmptyState
          title="No daily tasks"
          body="Add one above and it appears on every miner's Daily screen, resetting at midnight UTC."
        />
      )}
      {tasks.data && tasks.data.length > 0 && (
        <Table head={["Task", "Reward", "Completions", "Status", ""]}>
          {tasks.data.map((t) => (
            <tr key={t.id}>
              <Td>
                <span className="block max-w-[22rem] truncate">{t.title}</span>
              </Td>
              <Td mono>{formatEly(t.reward, 4)}</Td>
              <Td mono muted>{t.completions}</Td>
              <Td>{t.active ? <Badge tone="jade">live</Badge> : <Badge tone="muted">hidden</Badge>}</Td>
              <Td>
                <span className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => update.mutate({ id: t.id, active: !t.active })}
                    className="rounded-full border border-border px-2.5 py-1 text-[0.65rem] font-medium text-muted-foreground hover:text-foreground"
                  >
                    {t.active ? "Hide" : "Publish"}
                  </button>
                  <button
                    type="button"
                    onClick={() => remove.mutate({ id: t.id })}
                    className="rounded-full border border-border px-2.5 py-1 text-[0.65rem] font-medium text-muted-foreground hover:border-destructive/40 hover:text-destructive"
                  >
                    Delete
                  </button>
                </span>
              </Td>
            </tr>
          ))}
        </Table>
      )}
    </div>
  );
}

// ── settings ─────────────────────────────────────────────────────────────────

function Settings() {
  const utils = trpc.useUtils();
  const settings = trpc.admin.settings.useQuery();
  const save = trpc.admin.saveSettings.useMutation({
    onSuccess: () => {
      void utils.admin.settings.invalidate();
      void utils.mining.status.invalidate();
    },
  });

  const [draft, setDraft] = useState<Record<string, string> | null>(null);
  const [flags, setFlags] = useState<{ maintenanceMode: boolean } | null>(null);
  const [saved, setSaved] = useState(false);

  if (settings.isLoading) return <PanelSkeleton lines={5} />;
  if (settings.isError) return <ErrorPanel message={settings.error.message} onRetry={() => void settings.refetch()} />;
  if (!settings.data) return null;

  const s = settings.data;
  const value = (k: keyof typeof s) => draft?.[k] ?? String(s[k]);
  const maintenance = flags?.maintenanceMode ?? s.maintenanceMode;

  function set(k: string, v: string) {
    setDraft((d) => ({ ...(d ?? {}), [k]: v }));
    setSaved(false);
  }

  async function onSave(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const num = (k: string, fallback: number) => {
      const n = Number(value(k as keyof typeof s));
      return Number.isFinite(n) ? n : fallback;
    };
    await save.mutateAsync({
      baseRatePerHour: num("baseRatePerHour", s.baseRatePerHour),
      boostPerMemberPerHour: num("boostPerMemberPerHour", s.boostPerMemberPerHour),
      maxBoostMembers: Math.round(num("maxBoostMembers", s.maxBoostMembers)),
      referralBonus: num("referralBonus", s.referralBonus),
      sessionHours: num("sessionHours", s.sessionHours),
      maintenanceMode: maintenance,
      maintenanceMessage: value("maintenanceMessage"),
      announcement: value("announcement"),
    });
    setSaved(true);
  }

  return (
    <form onSubmit={onSave} className="space-y-5">
      <Card>
        <Eyebrow>Emission</Eyebrow>
        <p className="mt-1.5 text-[0.7rem] leading-relaxed text-muted-foreground">
          These apply to sessions started from now on. A session already running keeps the rates it was
          opened with — that is what makes the accrual auditable.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Field label="Base rate (ELY / hour)" value={value("baseRatePerHour")} onChange={(v) => set("baseRatePerHour", v)} />
          <Field label="Boost per member (ELY / hour)" value={value("boostPerMemberPerHour")} onChange={(v) => set("boostPerMemberPerHour", v)} />
          <Field label="Max boost members" value={value("maxBoostMembers")} onChange={(v) => set("maxBoostMembers", v)} />
          <Field label="Referral bonus (ELY, once)" value={value("referralBonus")} onChange={(v) => set("referralBonus", v)} />
          <Field label="Session length (hours)" value={value("sessionHours")} onChange={(v) => set("sessionHours", v)} />
        </div>
      </Card>

      <Card>
        <Eyebrow>Network</Eyebrow>
        <div className="mt-3 space-y-3">
          <label className="flex items-start gap-2.5">
            <input
              type="checkbox"
              checked={maintenance}
              onChange={(e) => {
                setFlags({ maintenanceMode: e.target.checked });
                setSaved(false);
              }}
              className="mt-0.5 h-4 w-4 accent-[#2fd6a5]"
            />
            <span>
              <span className="block text-sm text-foreground">Maintenance mode</span>
              <span className="mt-0.5 block text-[0.7rem] leading-relaxed text-muted-foreground">
                Refuses new sessions and claims with the message below. Running sessions keep accruing.
              </span>
            </span>
          </label>
          <Field
            label="Maintenance message"
            value={value("maintenanceMessage")}
            onChange={(v) => set("maintenanceMessage", v)}
            wide
          />
          <Field
            label="Banner on the mining screen (leave empty for none)"
            value={value("announcement")}
            onChange={(v) => set("announcement", v)}
            wide
          />
        </div>
      </Card>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={save.isPending}
          className="h-10 rounded-full bg-jade px-5 text-sm font-semibold text-[#04140f] disabled:opacity-60"
        >
          {save.isPending ? "Saving…" : "Save settings"}
        </button>
        {saved && !save.isPending && <span className="text-xs text-jade">Saved — live for the next session.</span>}
        {save.error && <span className="text-xs text-destructive">{save.error.message}</span>}
      </div>
    </form>
  );
}

function Field({
  label,
  value,
  onChange,
  wide,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  wide?: boolean;
}) {
  return (
    <label className={cn("block", wide && "sm:col-span-2")}>
      <span className="block text-[0.7rem] text-muted-foreground">{label}</span>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="ely-num mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-jade/60"
      />
    </label>
  );
}

// ── security ─────────────────────────────────────────────────────────────────

/**
 * The owner's own credentials. Changing the password here is what makes the
 * console self-sufficient: no code edit, no rebuild, no asking anyone.
 */
function Security({ email }: { email: string }) {
  const change = trpc.admin.changePassword.useMutation();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [done, setDone] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLocalError(null);
    setDone(false);
    if (next !== confirm) {
      setLocalError("The two new passwords do not match.");
      return;
    }
    try {
      await change.mutateAsync({ currentPassword: current, newPassword: next });
      setDone(true);
      setCurrent("");
      setNext("");
      setConfirm("");
    } catch {
      /* surfaced below */
    }
  }

  return (
    <div className="space-y-5">
      <Card>
        <Eyebrow>Signed in as</Eyebrow>
        <p className="mt-1.5 text-sm text-foreground">{email}</p>
        <p className="mt-1 text-[0.7rem] leading-relaxed text-muted-foreground">
          This address is on the ADMIN_EMAILS allowlist, which is what grants the console. To change
          which addresses are admins, edit that value in Web Admin → Secrets.
        </p>
      </Card>

      <Card>
        <Eyebrow>Change your password</Eyebrow>
        <form onSubmit={onSubmit} className="mt-3 space-y-2.5">
          <label className="block">
            <span className="block text-[0.7rem] text-muted-foreground">Current password</span>
            <input
              type="password"
              value={current}
              onChange={(e) => setCurrent(e.target.value)}
              required
              autoComplete="current-password"
              className="mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-gold/60"
            />
          </label>
          <div className="grid gap-2.5 sm:grid-cols-2">
            <label className="block">
              <span className="block text-[0.7rem] text-muted-foreground">New password</span>
              <input
                type="password"
                value={next}
                onChange={(e) => setNext(e.target.value)}
                required
                minLength={8}
                autoComplete="new-password"
                className="mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-gold/60"
              />
            </label>
            <label className="block">
              <span className="block text-[0.7rem] text-muted-foreground">Confirm new password</span>
              <input
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                required
                minLength={8}
                autoComplete="new-password"
                className="mt-1 h-10 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none focus:border-gold/60"
              />
            </label>
          </div>

          {(localError || change.error) && (
            <p className="text-xs text-destructive">{localError ?? change.error?.message}</p>
          )}
          {done && <p className="text-xs text-jade">Password changed. Use it next time you sign in.</p>}

          <button
            type="submit"
            disabled={change.isPending}
            className="h-10 rounded-full bg-gold px-5 text-sm font-semibold text-[#1a1405] disabled:opacity-60"
          >
            {change.isPending ? "Saving…" : "Change password"}
          </button>
        </form>
      </Card>
    </div>
  );
}
