import { useState, type FormEvent } from "react";
import { Link, Redirect } from "wouter";
import { useAuth } from "@/_core/useAuth";
import { trpc } from "@/_core/trpc";
import { Wordmark, Eyebrow } from "@/components/ely";

/**
 * The admin console's own door. Deliberately separate from the miner login:
 * the owner bookmarks /admin/login, signs in with their admin credentials, and
 * lands straight in the console — no miner screens in between.
 *
 * Signing in here uses the same account system as the app (one identity, one
 * password), but the destination and the framing are the operator's.
 */
export default function AdminLogin() {
  const { login, user, isLoading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // Only ask the server who this is once we know somebody is signed in.
  const whoami = trpc.admin.whoami.useQuery(undefined, { enabled: Boolean(user) });

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await login(email, password);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  }

  if (isLoading) {
    return <div className="mx-auto max-w-md px-5 py-16 text-center text-sm text-muted-foreground">Loading…</div>;
  }

  // Signed in and actually an admin → straight into the console.
  if (user && whoami.data?.isAdmin) return <Redirect to="/admin" />;

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-14">
      <div className="mb-9">
        <Wordmark size="lg" />
        <p className="mt-3 flex items-center gap-2">
          <span className="rounded-full border border-gold/30 bg-gold/[0.06] px-2.5 py-0.5 text-[0.6rem] font-medium uppercase tracking-[0.18em] text-gold">
            Admin console
          </span>
        </p>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Sign in with your admin account to manage the network.
        </p>
      </div>

      {user && whoami.data && !whoami.data.isAdmin && (
        <div className="mb-5 rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-3">
          <p className="text-xs font-medium text-destructive">This account is not an admin</p>
          <p className="mt-1 text-[0.7rem] leading-relaxed text-muted-foreground">
            You are signed in as {whoami.data.email}. Sign out and use the address listed in the
            ADMIN_EMAILS setting, or add this address to that setting.
          </p>
        </div>
      )}

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Eyebrow>Admin email</Eyebrow>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="username"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-gold/60"
            placeholder="you@example.com"
          />
        </div>
        <div className="space-y-1.5">
          <Eyebrow>Password</Eyebrow>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-gold/60"
            placeholder="••••••••"
          />
        </div>

        {error && (
          <p className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-2.5 text-xs leading-relaxed text-destructive">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="h-12 w-full rounded-full bg-gold text-sm font-semibold text-[#1a1405] transition-all hover:brightness-105 disabled:opacity-60"
        >
          {busy ? "Signing in…" : "Sign in to console"}
        </button>
      </form>

      <p className="mt-8 text-center text-[0.7rem] text-muted-foreground/70">
        <Link to="/" className="hover:text-foreground">
          ← Back to Elyndra
        </Link>
      </p>
    </div>
  );
}
