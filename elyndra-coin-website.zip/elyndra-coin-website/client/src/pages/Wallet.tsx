import { trpc } from "@/_core/trpc";
import {
  Shell,
  TabBar,
  PageHeader,
  Eyebrow,
  Stat,
  EmptyState,
  PanelSkeleton,
  ErrorPanel,
  SimulationNotice,
} from "@/components/ely";
import { formatEly } from "@shared/mining";

export default function Wallet() {
  const status = trpc.mining.status.useQuery();
  const ledger = trpc.mining.ledger.useQuery();

  return (
    <>
      <Shell>
        <PageHeader title="Wallet" subtitle="Your balance and every credit that built it." />

        {status.isLoading && <PanelSkeleton lines={3} />}
        {status.isError && (
          <ErrorPanel message={status.error.message} onRetry={() => void status.refetch()} />
        )}

        {status.data && (
          <div className="ely-rise space-y-6">
            <section className="ely-panel relative overflow-hidden px-5 py-6">
              <div
                className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-jade/10 blur-2xl"
                aria-hidden
              />
              <Eyebrow>Balance</Eyebrow>
              <p className="ely-num mt-2 text-[3.1rem] leading-none text-foreground">
                {formatEly(status.data.profile.balance, 4)}
              </p>
              <p className="mt-1.5 text-[0.7rem] font-medium tracking-[0.24em] text-gold">ELY</p>

              <div className="ely-hairline mt-5 grid grid-cols-2 gap-4 pt-4">
                <div>
                  <Eyebrow>Total mined</Eyebrow>
                  <p className="ely-num mt-1 text-lg text-foreground">
                    {formatEly(status.data.profile.totalMined, 4)}
                  </p>
                </div>
                <div>
                  <Eyebrow>In session</Eyebrow>
                  <p className="ely-num mt-1 text-lg text-jade">
                    {status.data.session ? formatEly(status.data.session.accrued, 4) : "—"}
                  </p>
                </div>
              </div>
            </section>

            <section className="grid grid-cols-2 gap-2.5">
              <Stat
                label="Rate"
                value={`${formatEly(status.data.rates.total, 4)}`}
                hint="ELY per hour"
                accent="jade"
              />
              <Stat
                label="Circle"
                value={`${status.data.team.active}/${status.data.team.total}`}
                hint="active / invited"
                accent="gold"
              />
            </section>

            <section>
              <div className="mb-2.5 flex items-baseline justify-between">
                <Eyebrow>History</Eyebrow>
                <span className="text-[0.7rem] text-muted-foreground">
                  {ledger.data ? `${ledger.data.length} entries` : ""}
                </span>
              </div>

              {ledger.isLoading && <PanelSkeleton lines={3} />}
              {ledger.isError && (
                <ErrorPanel message={ledger.error.message} onRetry={() => void ledger.refetch()} />
              )}

              {ledger.data && ledger.data.length === 0 && (
                <EmptyState
                  title="Nothing claimed yet"
                  body="Your first entry appears when a 24-hour session finishes and you claim it. Start a session from the Mine tab."
                />
              )}

              {ledger.data && ledger.data.length > 0 && (
                <ul className="ely-panel divide-y divide-border/70">
                  {ledger.data.map((entry) => (
                    <li key={entry.id} className="flex items-center justify-between gap-3 px-4 py-3.5">
                      <div className="min-w-0">
                        <p className="text-sm text-foreground">
                          {entry.type === "referral_bonus" ? "Referral bonus" : "Mining session"}
                        </p>
                        <p className="mt-0.5 text-[0.7rem] text-muted-foreground">
                          {new Date(entry.createdAt).toLocaleString(undefined, {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                      <span
                        className={
                          entry.type === "referral_bonus"
                            ? "ely-num shrink-0 text-sm text-gold"
                            : "ely-num shrink-0 text-sm text-jade"
                        }
                      >
                        +{formatEly(entry.amount, 4)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <SimulationNotice />
          </div>
        )}
      </Shell>
      <TabBar />
    </>
  );
}
