import { useMemo, useState, type FormEvent } from "react";
import { Link, Redirect } from "wouter";
import { useAuth } from "@/_core/useAuth";
import { trpc } from "@/_core/trpc";
import { requestStorageAccessIfEmbedded } from "@/_core/storage-access";
import { Shell, Wordmark, Eyebrow, SimulationNotice } from "@/components/ely";

/** Read `?ref=CODE` from the URL — the referral link a friend shared. */
function useRefCode(): string {
  return useMemo(() => {
    if (typeof window === "undefined") return "";
    const raw = new URLSearchParams(window.location.search).get("ref") ?? "";
    return raw.trim().toUpperCase().slice(0, 16);
  }, []);
}

export default function Register() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const signup = trpc.auth.signup.useMutation();
  const refCode = useRefCode();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await requestStorageAccessIfEmbedded();
      await signup.mutateAsync({
        email,
        password,
        name: name.trim(),
        refCode: refCode || undefined,
      });
      await utils.auth.me.invalidate();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Signup failed");
    } finally {
      setBusy(false);
    }
  }

  if (user) return <Redirect to="/mine" />;

  return (
    <Shell className="justify-center pb-14">
      <div className="mb-8">
        <Wordmark size="lg" />
        <p className="mt-3 text-sm text-muted-foreground">
          Create your account and open your first mining session.
        </p>
      </div>

      {refCode && (
        <div className="mb-5 rounded-lg border border-jade/25 bg-jade/[0.05] px-3.5 py-3">
          <p className="text-xs leading-relaxed text-muted-foreground">
            You were invited with code{" "}
            <span className="ely-num font-semibold tracking-wider text-jade">{refCode}</span> — they
            join your Security Circle when you start mining.
          </p>
        </div>
      )}

      <form onSubmit={onSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <Eyebrow>Name</Eyebrow>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            minLength={2}
            maxLength={60}
            autoComplete="name"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-jade/60"
            placeholder="How should we call you?"
          />
        </div>
        <div className="space-y-1.5">
          <Eyebrow>Email</Eyebrow>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            autoComplete="email"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-jade/60"
            placeholder="you@example.com"
          />
        </div>
        <div className="space-y-1.5">
          <Eyebrow>Password</Eyebrow>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={8}
            autoComplete="new-password"
            className="h-12 w-full rounded-lg border border-input bg-panel px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/60 focus:border-jade/60"
            placeholder="At least 8 characters"
          />
        </div>

        {error && (
          <p className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-2.5 text-xs leading-relaxed text-destructive">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={busy}
          className="h-12 w-full rounded-full bg-jade text-sm font-semibold text-[#04140f] transition-all hover:brightness-105 disabled:opacity-60"
        >
          {busy ? "Creating…" : "Create account"}
        </button>
      </form>

      <div className="mt-6">
        <SimulationNotice compact />
      </div>

      <p className="mt-5 text-center text-xs text-muted-foreground">
        Already have an account?{" "}
        <Link to="/login" className="font-medium text-jade underline underline-offset-4">
          Log in
        </Link>
      </p>
    </Shell>
  );
}
