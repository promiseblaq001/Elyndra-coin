import { useState } from "react";
import { trpc } from "@/_core/trpc";
import {
  Shell,
  TabBar,
  PageHeader,
  Eyebrow,
  Stat,
  PanelSkeleton,
  ErrorPanel,
  EmptyState,
  SimulationNotice,
} from "@/components/ely";
import { formatEly } from "@shared/mining";
import { formatDuration } from "@shared/mining";
import { cn } from "@/lib/utils";

/**
 * The daily task screen. Progress is server-derived: `done` comes from a row in
 * `daily_completions` for today's UTC date, so it cannot be faked by the client
 * and it resets on its own at midnight UTC.
 */
export default function Daily() {
  const utils = trpc.useUtils();
  const progress = trpc.daily.progress.useQuery(undefined, { refetchInterval: 60_000 });
  const complete = trpc.daily.complete.useMutation({
    onSuccess: () => {
      void utils.daily.progress.invalidate();
      void utils.mining.status.invalidate();
      void utils.mining.ledger.invalidate();
    },
  });
  const [notice, setNotice] = useState<string | null>(null);

  async function onComplete(taskId: string, title: string) {
    setNotice(null);
    try {
      const res = await complete.mutateAsync({ taskId });
      setNotice(`+${formatEly(res.amount, 4)} ELY for “${title}”.`);
    } catch {
      /* surfaced below */
    }
  }

  return (
    <>
      <Shell>
        <PageHeader
          title="Daily"
          subtitle="Small tasks, once a day. They reset at midnight UTC."
        />

        {progress.isLoading && <PanelSkeleton lines={4} />}
        {progress.isError && (
          <ErrorPanel message={progress.error.message} onRetry={() => void progress.refetch()} />
        )}

        {progress.data && (
          <div className="ely-rise space-y-6">
            <section className="grid grid-cols-2 gap-2.5">
              <Stat
                label="Today"
                value={`${progress.data.completedCount}/${progress.data.totalCount}`}
                hint="tasks completed"
                accent="jade"
              />
              <Stat
                label="Streak"
                value={`${progress.data.streak}d`}
                hint="consecutive days"
                accent="gold"
              />
            </section>

            <section className="ely-panel flex items-baseline justify-between px-4 py-3.5">
              <span className="text-xs text-muted-foreground">Earned from tasks today</span>
              <span className="ely-num text-lg text-jade">
                {formatEly(progress.data.earnedToday, 4)}{" "}
                <span className="text-[0.7rem] tracking-widest text-muted-foreground">ELY</span>
              </span>
            </section>

            {notice && (
              <p className="rounded-lg border border-jade/25 bg-jade/[0.06] px-3.5 py-2.5 text-center text-xs leading-relaxed text-jade">
                {notice}
              </p>
            )}

            {complete.error && (
              <p className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-3.5 py-2.5 text-center text-xs leading-relaxed text-destructive">
                {complete.error.message}
              </p>
            )}

            <section>
              <div className="flex items-baseline justify-between">
                <Eyebrow>Today&apos;s tasks</Eyebrow>
                <span className="text-[0.65rem] text-muted-foreground">
                  resets in {formatDuration(progress.data.resetsInMs)}
                </span>
              </div>

              <div className="mt-2.5 space-y-2.5">
                {progress.data.tasks.length === 0 && (
                  <EmptyState
                    title="No tasks today"
                    body="The network has not published any daily tasks yet. Check back soon — they appear here as soon as an admin adds one."
                  />
                )}

                {progress.data.tasks.map((t) => (
                  <div
                    key={t.id}
                    className={cn(
                      "ely-panel px-4 py-4 transition-colors",
                      t.done && "border-jade/25 bg-jade/[0.03]",
                    )}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-foreground">{t.title}</p>
                        {t.body && (
                          <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{t.body}</p>
                        )}
                        <p className="mt-2 text-[0.7rem] text-gold">
                          +{formatEly(t.reward, 4)} ELY
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={t.done || complete.isPending}
                        onClick={() => void onComplete(t.id, t.title)}
                        className={cn(
                          "h-9 shrink-0 rounded-full px-3.5 text-[0.7rem] font-semibold transition-all",
                          t.done
                            ? "border border-jade/30 bg-jade/[0.08] text-jade"
                            : "bg-jade text-[#04140f] hover:brightness-105 disabled:opacity-60",
                        )}
                      >
                        {t.done ? "Done ✓" : complete.isPending ? "…" : "Complete"}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <SimulationNotice compact />
          </div>
        )}
      </Shell>
      <TabBar />
    </>
  );
}
