import { Link } from "wouter";
import { useAuth } from "@/_core/useAuth";
import { Shell, Wordmark, Eyebrow, SimulationNotice } from "@/components/ely";
import {
  BASE_RATE_PER_HOUR,
  BOOST_PER_MEMBER_PER_HOUR,
  MAX_BOOST_MEMBERS,
  REFERRAL_BONUS,
  SESSION_HOURS,
  formatEly,
} from "@shared/mining";

const STEPS = [
  {
    n: "01",
    title: "Tap once a day",
    body: "One tap opens a 24-hour mining session. There is nothing to keep open — the session runs on the server.",
  },
  {
    n: "02",
    title: "Let it accrue",
    body: `Emission is deliberately slow: ${formatEly(BASE_RATE_PER_HOUR, 4)} ELY per hour, about ${formatEly(BASE_RATE_PER_HOUR * SESSION_HOURS, 2)} ELY for a full session.`,
  },
  {
    n: "03",
    title: "Grow your circle",
    body: `Each active member of your Security Circle adds ${formatEly(BOOST_PER_MEMBER_PER_HOUR, 4)} ELY/hr, up to ${MAX_BOOST_MEMBERS} members.`,
  },
];

export default function Home() {
  const { user } = useAuth();

  return (
    <Shell className="pb-14">
      <header className="flex items-center justify-between">
        <Wordmark />
        <Link
          to={user ? "/mine" : "/login"}
          className="rounded-full border border-border px-3.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-jade/40 hover:text-foreground"
        >
          {user ? "Open app" : "Log in"}
        </Link>
      </header>

      <section className="ely-rise mt-14">
        <Eyebrow>A mobile mining network</Eyebrow>
        <h1 className="ely-display mt-3 text-[2.9rem] leading-[1.05] text-foreground">
          Mine slowly.
          <br />
          <span className="text-jade">Grow quietly.</span>
        </h1>
        <p className="mt-5 max-w-[36ch] text-sm leading-relaxed text-muted-foreground">
          Elyndra is a mining network you carry in your pocket. One tap a day keeps a session alive;
          the coins accrue hour by hour, whether the app is open or not.
        </p>

        <div className="mt-8 flex flex-col gap-2.5">
          <Link
            to={user ? "/mine" : "/register"}
            className="flex h-12 items-center justify-center rounded-full bg-jade text-sm font-semibold text-[#04140f] transition-all hover:brightness-105"
          >
            {user ? "Go to mining" : "Start mining"}
          </Link>
          {!user && (
            <Link
              to="/login"
              className="flex h-12 items-center justify-center rounded-full border border-border text-sm font-medium text-foreground transition-colors hover:border-gold/40"
            >
              I already have an account
            </Link>
          )}
        </div>
      </section>

      {/* Emission model — the numbers, stated plainly. */}
      <section className="mt-14">
        <Eyebrow>The emission model</Eyebrow>
        <div className="ely-panel mt-3 divide-y divide-border/70">
          <Row label="Base rate" value={`${formatEly(BASE_RATE_PER_HOUR, 4)} ELY / hr`} />
          <Row
            label="Per session"
            value={`${formatEly(BASE_RATE_PER_HOUR * SESSION_HOURS, 2)} ELY / ${SESSION_HOURS}h`}
          />
          <Row
            label="Circle boost"
            value={`+${formatEly(BOOST_PER_MEMBER_PER_HOUR, 4)} ELY / hr each`}
          />
          <Row label="Boost cap" value={`${MAX_BOOST_MEMBERS} members`} />
          <Row label="Referral bonus" value={`${formatEly(REFERRAL_BONUS, 2)} ELY once`} />
        </div>
        <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
          Rates are locked in when a session starts, so a boost you earn today applies from your next
          session. A session ends after {SESSION_HOURS} hours — claim it, then tap again.
        </p>
      </section>

      {/* How it works */}
      <section className="mt-14">
        <Eyebrow>How it works</Eyebrow>
        <div className="mt-3 space-y-2.5">
          {STEPS.map((s) => (
            <div key={s.n} className="ely-panel flex gap-4 px-4 py-4">
              <span className="ely-num shrink-0 text-lg text-gold/70">{s.n}</span>
              <div>
                <p className="text-sm font-medium text-foreground">{s.title}</p>
                <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{s.body}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <SimulationNotice />
      </section>

      <footer className="ely-hairline mt-10 pt-6 text-center">
        <Wordmark size="sm" />
        <p className="mt-2 text-[0.7rem] text-muted-foreground">
          A mining-network simulation. Not an investment.
        </p>
      </footer>
    </Shell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between px-4 py-3.5">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="ely-num text-sm text-foreground">{value}</span>
    </div>
  );
}
