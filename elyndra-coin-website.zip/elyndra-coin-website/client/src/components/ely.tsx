import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

/**
 * The 480px mobile shell every page sits in. On desktop it floats as a phone-
 * width column with a hairline edge; on a phone it is simply the screen.
 */
export function Shell({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className="ely-shell flex flex-col">
      <div className={cn("flex flex-1 flex-col px-5 pb-28 pt-6", className)}>{children}</div>
    </div>
  );
}

/** Small caps label used above a value or a section. */
export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return <p className={cn("ely-eyebrow", className)}>{children}</p>;
}

/** The wordmark: "Elyndra" in the display serif, "COIN" tracked out in gold. */
export function Wordmark({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const scale = size === "lg" ? "text-4xl" : size === "sm" ? "text-lg" : "text-2xl";
  return (
    <span className="inline-flex items-baseline gap-2">
      <span className={cn("ely-display text-foreground", scale)}>Elyndra</span>
      <span
        className={cn(
          "font-medium uppercase text-gold",
          size === "lg" ? "text-[0.7rem] tracking-[0.42em]" : "text-[0.6rem] tracking-[0.34em]",
        )}
      >
        Coin
      </span>
    </span>
  );
}

/** A labelled figure — the workhorse of the wallet and rate breakdown. */
export function Stat({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  accent?: "jade" | "gold" | "plain";
}) {
  return (
    <div className="ely-panel px-4 py-3.5">
      <Eyebrow>{label}</Eyebrow>
      <p
        className={cn(
          "ely-num mt-1.5 text-2xl leading-none",
          accent === "jade" && "text-jade",
          accent === "gold" && "text-gold",
          (!accent || accent === "plain") && "text-foreground",
        )}
      >
        {value}
      </p>
      {hint && <p className="mt-1.5 text-xs leading-snug text-muted-foreground">{hint}</p>}
    </div>
  );
}

/** The standing honesty notice. Present on every screen that shows a balance. */
export function SimulationNotice({ compact = false }: { compact?: boolean }) {
  return (
    <div
      className={cn(
        "rounded-lg border border-gold/20 bg-gold/[0.04] px-3.5 py-3",
        compact ? "text-[0.7rem] leading-relaxed" : "text-xs leading-relaxed",
      )}
    >
      <span className="font-medium text-gold">Simulation.</span>{" "}
      <span className="text-muted-foreground">
        Elyndra is a mining-network simulation. There is no blockchain, no real token, no cash value
        and no withdrawal — balances are app records only.
      </span>
    </div>
  );
}

const NAV = [
  { href: "/mine", label: "Mine", glyph: "◉" },
  { href: "/daily", label: "Daily", glyph: "✦" },
  { href: "/team", label: "Circle", glyph: "◎" },
  { href: "/wallet", label: "Wallet", glyph: "◇" },
  { href: "/profile", label: "You", glyph: "◌" },
] as const;

/** Fixed bottom tab bar for the signed-in app. */
export function TabBar() {
  const [location] = useLocation();
  return (
    <nav className="fixed inset-x-0 bottom-0 z-20 mx-auto w-full max-w-[480px] border-t border-border/80 bg-[#070b14]/92 backdrop-blur-xl">
      <div className="grid grid-cols-5 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-2">
        {NAV.map((item) => {
          const active = location === item.href;
          return (
            <Link
              key={item.href}
              to={item.href}
              className={cn(
                "flex flex-col items-center gap-1 rounded-lg py-1.5 transition-colors",
                active ? "text-jade" : "text-muted-foreground hover:text-foreground",
              )}
            >
              <span className={cn("text-base leading-none", active && "drop-shadow-[0_0_8px_rgba(47,214,165,0.6)]")}>
                {item.glyph}
              </span>
              <span className="text-[0.65rem] font-medium tracking-wide">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

/** Page header with an optional back link. */
export function PageHeader({
  title,
  subtitle,
  back,
}: {
  title: string;
  subtitle?: string;
  back?: string;
}) {
  return (
    <header className="mb-6">
      {back && (
        <Link to={back} className="mb-3 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
          ← Back
        </Link>
      )}
      <h1 className="ely-display text-3xl leading-tight text-foreground">{title}</h1>
      {subtitle && <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{subtitle}</p>}
    </header>
  );
}

/** Designed empty state — every list in the app has one. */
export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: ReactNode;
}) {
  return (
    <div className="ely-panel flex flex-col items-center gap-2 px-6 py-10 text-center">
      <div className="mb-1 flex h-11 w-11 items-center justify-center rounded-full border border-border text-lg text-muted-foreground">
        ◌
      </div>
      <p className="ely-display text-lg text-foreground">{title}</p>
      <p className="max-w-[34ch] text-xs leading-relaxed text-muted-foreground">{body}</p>
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

/** Loading skeleton for a panel. */
export function PanelSkeleton({ lines = 3 }: { lines?: number }) {
  return (
    <div className="ely-panel animate-pulse space-y-2.5 px-4 py-4">
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className="h-3 rounded bg-muted"
          style={{ width: `${[70, 92, 55, 80][i % 4]}%` }}
        />
      ))}
    </div>
  );
}

/** Inline error with a retry. */
export function ErrorPanel({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="rounded-lg border border-destructive/30 bg-destructive/[0.06] px-4 py-3.5">
      <p className="text-sm font-medium text-destructive">Something went wrong</p>
      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="mt-2.5 text-xs font-medium text-jade underline underline-offset-4"
        >
          Try again
        </button>
      )}
    </div>
  );
}
