import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { accrualFor, formatDuration, formatEly, sessionProgress } from "@shared/mining";
import type { MiningSessionView } from "@shared/mining";

/**
 * A clock that ticks locally but is anchored to the server's clock, so the
 * counter moves smoothly between polls without ever trusting the device's own
 * idea of "now". The offset is recomputed on every server response.
 */
export function useServerClock(serverNow: string | undefined) {
  const offsetRef = useRef(0);
  const [, force] = useState(0);

  if (serverNow) {
    const parsed = new Date(serverNow).getTime();
    if (Number.isFinite(parsed)) offsetRef.current = parsed - Date.now();
  }

  useEffect(() => {
    const id = window.setInterval(() => force((n) => n + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  return Date.now() + offsetRef.current;
}

/**
 * The mining orb. Three states, each visually distinct:
 *   idle     — no session; a dim ring, "Tap to begin"
 *   mining   — a slow jade pulse, live accrual inside
 *   complete — the 24h is up; gold, "Claim"
 */
export function MiningOrb({
  session,
  now,
  onStart,
  onClaim,
  busy,
  disabled,
}: {
  session: MiningSessionView | null;
  now: number;
  onStart: () => void;
  onClaim: () => void;
  busy: boolean;
  disabled?: boolean;
}) {
  const running = !!session && session.remainingMs > 0;
  const finished = !!session && session.remainingMs <= 0;

  const accrued = session
    ? accrualFor({
        startedAt: session.startedAt,
        endsAt: session.endsAt,
        now,
        baseRate: session.baseRate,
        boostRate: session.boostRate,
      })
    : 0;

  const progress = session
    ? sessionProgress({ startedAt: session.startedAt, endsAt: session.endsAt, now })
    : 0;

  const remaining = session ? Math.max(0, new Date(session.endsAt).getTime() - now) : 0;

  const label = running ? "Mining" : finished ? "Session complete" : "Ready to mine";
  const action = running ? null : finished ? "Claim" : "Start mining";
  const handler = finished ? onClaim : onStart;

  // The progress arc: a conic sweep behind the orb, drawn from the session.
  const arc = `conic-gradient(from -90deg, rgba(47,214,165,0.55) ${progress * 360}deg, rgba(28,39,64,0.9) ${progress * 360}deg)`;

  return (
    <div className="flex flex-col items-center">
      <div className="relative flex h-[268px] w-[268px] items-center justify-center">
        {/* progress arc */}
        <div
          className="absolute inset-0 rounded-full opacity-70"
          style={{ background: arc, mask: "radial-gradient(circle, transparent 61%, #000 62%)", WebkitMask: "radial-gradient(circle, transparent 61%, #000 62%)" }}
          aria-hidden
        />
        {/* slow drifting hairline ring */}
        <div
          className="ely-ring absolute inset-[14px] rounded-full border border-dashed border-gold/20"
          aria-hidden
        />

        <button
          type="button"
          onClick={handler}
          disabled={busy || disabled || running}
          aria-label={action ?? "Mining in progress"}
          className={cn(
            "relative flex h-[212px] w-[212px] flex-col items-center justify-center rounded-full",
            "border transition-transform duration-300 active:scale-[0.985]",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-jade/60 focus-visible:ring-offset-4 focus-visible:ring-offset-background",
            running && "ely-orb border-jade/40 bg-[radial-gradient(circle_at_50%_38%,rgba(47,214,165,0.20),rgba(7,11,20,0.96)_68%)]",
            finished && "border-gold/50 bg-[radial-gradient(circle_at_50%_38%,rgba(232,200,122,0.20),rgba(7,11,20,0.96)_68%)] shadow-[0_0_70px_8px_rgba(232,200,122,0.18)]",
            !session && "ely-orb-idle border-border bg-[radial-gradient(circle_at_50%_38%,rgba(143,160,184,0.10),rgba(7,11,20,0.96)_68%)]",
            (busy || disabled) && "opacity-70",
          )}
        >
          <span className="ely-eyebrow mb-1.5">{label}</span>

          {session ? (
            <>
              <span className="ely-num text-[2.6rem] leading-none text-foreground">
                {formatEly(accrued, 4)}
              </span>
              <span className="mt-1 text-[0.7rem] font-medium tracking-[0.2em] text-gold">ELY</span>
              <span className="mt-3 text-[0.7rem] tabular-nums text-muted-foreground">
                {running ? `${formatDuration(remaining)} left` : "24h elapsed"}
              </span>
            </>
          ) : (
            <>
              <span className="ely-display text-2xl text-foreground">Tap to begin</span>
              <span className="mt-2 max-w-[15ch] text-center text-[0.7rem] leading-snug text-muted-foreground">
                One tap opens a 24-hour session
              </span>
            </>
          )}
        </button>
      </div>

      {action && (
        <button
          type="button"
          onClick={handler}
          disabled={busy || disabled}
          className={cn(
            "mt-6 h-11 w-full max-w-[260px] rounded-full text-sm font-semibold tracking-wide transition-all",
            "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-background",
            finished
              ? "bg-gold text-[#1a1405] hover:brightness-105 focus-visible:ring-gold/60"
              : "bg-jade text-[#04140f] hover:brightness-105 focus-visible:ring-jade/60",
            (busy || disabled) && "opacity-60",
          )}
        >
          {busy ? "Working…" : action}
        </button>
      )}

      {running && (
        <p className="mt-6 max-w-[30ch] text-center text-xs leading-relaxed text-muted-foreground">
          Mining continues while the app is closed — the balance is computed from the session
          timestamps on the server, not from this screen.
        </p>
      )}
    </div>
  );
}
