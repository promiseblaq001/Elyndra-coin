INSERT INTO daily_tasks (title, body, reward, active, sort_order) VALUES
  ('Open your mining session', 'Tap the orb on the Mine screen to keep a 24-hour session running. This is the one action the whole network depends on.', 0.01, true, 0),
  ('Check in on your Security Circle', 'Open the Circle screen and see who is active. Each active member adds to your hourly rate.', 0.005, true, 1),
  ('Invite one person', 'Share your referral link with someone who would mine alongside you. You earn a one-time bonus when they claim their first session.', 0.005, true, 2)
ON CONFLICT DO NOTHING;
