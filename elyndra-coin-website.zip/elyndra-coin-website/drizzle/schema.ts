import { sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  text,
  timestamp,
  index,
  uniqueIndex,
  bigint,
  boolean,
  doublePrecision,
  integer,
} from "drizzle-orm/pg-core";

// ─────────────────────────────────────────────────────────────────────────────
// SYSTEM TABLE — managed by the scaffold. The Agent MUST NOT redefine or drop
// the auth columns here; it only ADDS business tables below (DESIGN §5.1).
//
// `password_hash` is LOCAL-auth-only. It is deliberately confined to this table
// and to server/_core/auth.ts — it never appears in SessionUser or any tRPC
// output. A future SsoAuthProvider would leave it null and link identities via
// an external-subject column; business tables keep FK'ing users.id regardless,
// so switching auth providers needs no business-schema change.
// ─────────────────────────────────────────────────────────────────────────────
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"), // null for SSO-linked users (future)
  name: text("name"),
  role: text("role").notNull().default("user"), // 'user' | 'admin'
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// SYSTEM TABLE — managed by the scaffold, written by server/_core/storage.ts.
// The Agent MUST NOT redefine, rename or drop it: `_core` inserts into it, so a
// rename breaks `_core`. Rows are created by storageCommit() AFTER the upload
// landed, with size/contentType read back from object storage — never from the
// client — so a row cannot point at an object that does not exist AT COMMIT TIME.
//
// That guarantee can still go stale: the platform's owner-facing storage panel
// can delete the underlying object directly. It has no access to this app's
// database, so it cannot (and does not) delete the matching row here. A row
// existing is therefore NOT a guarantee its object still exists — treat a 404
// from `/app-storage/<key>` as an expected, handle-able case in the UI, not a
// bug. `/app-storage/<key>` is also unauthenticated (no session check), so the
// URL itself is the read capability — never store something there that must
// not leak to anyone who obtains the link.
export const files = pgTable(
  "files",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    // Path relative to this app's storage prefix; served at /app-storage/<key>.
    key: text("key").notNull().unique(),
    // Nullable on purpose: a public "contact form with attachment" has no
    // logged-in uploader. set null (not cascade) on user delete — this table is
    // the app's ONLY index of its objects, so deleting the row would
    // permanently lose the ability to find the file.
    ownerId: uuid("owner_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(), // original filename, for display
    size: bigint("size", { mode: "number" }).notNull(), // bigint: integer caps at ~2.1GB
    contentType: text("content_type"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("files_owner_idx").on(t.ownerId), index("files_created_idx").on(t.createdAt)],
);

// ─────────────────────────────────────────────────────────────────────────────
// BUSINESS TABLES — Elyndra Coin
// ─────────────────────────────────────────────────────────────────────────────

/**
 * One row per account: the public identity (username, referral code), the
 * running balance, and who invited them. `balance` and `totalMined` are
 * denormalised totals; `ledger` is the audit trail that explains them.
 */
export const profiles = pgTable(
  "profiles",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: "cascade" }),
    username: text("username").notNull().unique(),
    referralCode: text("referral_code").notNull().unique(),
    /** The account whose code this user signed up with, if any. */
    referredById: uuid("referred_by_id").references(() => users.id, { onDelete: "set null" }),
    balance: doublePrecision("balance").notNull().default(0),
    totalMined: doublePrecision("total_mined").notNull().default(0),
    /**
     * Set by an admin. A suspended account keeps its balance and can still
     * claim a finished session, but cannot open a new one.
     */
    suspended: boolean("suspended").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("profiles_referred_by_idx").on(t.referredById)],
);

/**
 * A 24-hour mining session. `minedAmount` is only written at claim time, and is
 * always derived from the timestamps — never from anything the client sends.
 *
 * The partial unique index is the concurrency guard: a user can have at most one
 * unclaimed session, so two simultaneous "start" taps cannot both open one.
 */
export const miningSessions = pgTable(
  "mining_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    baseRate: doublePrecision("base_rate").notNull(),
    boostRate: doublePrecision("boost_rate").notNull().default(0),
    minedAmount: doublePrecision("mined_amount").notNull().default(0),
    claimed: boolean("claimed").notNull().default(false),
    claimedAt: timestamp("claimed_at", { withTimezone: true }),
    /**
     * Per-claim marker generated in TypeScript. Every write that depends on
     * "this call won the claim" is guarded by `exists (… where claim_ref = $n)`,
     * which is the only way to tell our own successful write from somebody
     * else's in a single atomic batch.
     */
    claimRef: text("claim_ref"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("mining_sessions_user_idx").on(t.userId),
    uniqueIndex("mining_sessions_open_unique").on(t.userId).where(sql`claimed = false`),
  ],
);

/**
 * A Security Circle edge: `referrerId` invited `refereeId`. `active` flips the
 * first time the referee starts a session, which is what earns the referrer the
 * rate boost. `bonusPaidAt` makes the one-time referral bonus exactly once.
 */
export const referrals = pgTable(
  "referrals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    referrerId: uuid("referrer_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    refereeId: uuid("referee_id")
      .notNull()
      .unique()
      .references(() => users.id, { onDelete: "cascade" }),
    active: boolean("active").notNull().default(false),
    bonusPaidAt: timestamp("bonus_paid_at", { withTimezone: true }),
    bonusRef: text("bonus_ref"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("referrals_referrer_idx").on(t.referrerId)],
);

/** Every credit to a balance, so the wallet can explain itself. */
export const ledger = pgTable(
  "ledger",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    amount: doublePrecision("amount").notNull(),
    /** 'mining' | 'referral_bonus' */
    type: text("type").notNull(),
    note: text("note"),
    sessionId: uuid("session_id").references(() => miningSessions.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ledger_user_idx").on(t.userId, t.createdAt)],
);

// ─────────────────────────────────────────────────────────────────────────────
// ADMIN-OWNED CONTENT — written only through the admin dashboard.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * A task or announcement the admin publishes to the network. `active` is the
 * publish switch — an inactive row stays in the dashboard but is invisible to
 * miners, so nothing has to be deleted to take it down.
 */
export const adminTasks = pgTable(
  "admin_tasks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    body: text("body").notNull().default(""),
    /** 'task' | 'announcement' */
    kind: text("kind").notNull().default("task"),
    active: boolean("active").notNull().default(true),
    /** Lower sorts first. Ties fall back to newest-first. */
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("admin_tasks_active_idx").on(t.active, t.sortOrder)],
);

/**
 * Site-wide settings as key/value rows, so the admin can change behaviour from
 * the browser without a deploy. Values are stored as text and parsed by
 * `getSettings()` — an unreadable value falls back to the default rather than
 * breaking the app.
 */
export const siteSettings = pgTable("site_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * A daily task a miner can complete once per calendar day. Admin-managed, so
 * the network can change what it asks for without a deploy.
 */
export const dailyTasks = pgTable(
  "daily_tasks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    body: text("body").notNull().default(""),
    /** ELY credited on completion. */
    reward: doublePrecision("reward").notNull().default(0.01),
    active: boolean("active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("daily_tasks_active_idx").on(t.active, t.sortOrder)],
);

/**
 * One row per user, per task, per day. The unique index is the whole anti-double
 * -claim story: a second tap on the same day cannot insert, so the reward is
 * paid exactly once no matter how many requests arrive.
 */
export const dailyCompletions = pgTable(
  "daily_completions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    taskId: uuid("task_id")
      .notNull()
      .references(() => dailyTasks.id, { onDelete: "cascade" }),
    /** UTC calendar day, `YYYY-MM-DD`. */
    day: text("day").notNull(),
    amount: doublePrecision("amount").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("daily_completions_unique").on(t.userId, t.taskId, t.day),
    index("daily_completions_user_idx").on(t.userId, t.day),
  ],
);
