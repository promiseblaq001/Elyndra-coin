# Elyndra Coin — Website Source

The complete source of the Elyndra Coin mining-network website: React + TypeScript
front end, Hono + tRPC back end, Drizzle ORM over Postgres.

> **Elyndra is a mining simulation.** No blockchain, no real token, no cash value,
> no withdrawal. Balances are app records only.

## Stack

| Layer | What |
|---|---|
| Front end | React 19, Vite, Tailwind CSS 4, wouter router, tRPC client |
| Back end | Hono, tRPC 11, Zod validation |
| Database | Postgres via Drizzle ORM (Neon serverless or plain `pg`) |
| Auth | Email + password, bcrypt hashes, JWT in an httpOnly cookie |
| Tests | Vitest (187 tests) |

## Layout

```
client/
  index.html
  src/
    App.tsx                 routes
    main.tsx                entry
    index.css               design tokens (midnight / jade / gold)
    _core/                  trpc client, auth hook, route guard, error boundary
    components/
      ely.tsx               shell, wordmark, stat, empty state, tab bar
      mining-orb.tsx        the tap-to-mine orb + server-anchored clock
      ui/                   button, card, input, label
    pages/
      Home.tsx              landing
      Login.tsx  Register.tsx
      Mine.tsx              orb, live accrual, countdown, rate breakdown
      Team.tsx              referral code, invite link, Security Circle
      Wallet.tsx            balance + ledger
      Profile.tsx
      Daily.tsx             daily tasks
      Admin.tsx             admin console (8 tabs)
      AdminLogin.tsx        separate admin sign-in
server/
  _core/                    auth, db, trpc, env, storage, jobs
  db.ts                     the mining engine — all accrual from timestamps
  routers.ts                tRPC procedures
  admin.ts                  admin procedures
  daily.ts                  daily-task procedures
  mobile-api.ts             REST surface used by the Expo app
shared/
  mining.ts                 emission model (pure, shared client + server)
  admin.ts  daily.ts  constants.ts  types.ts
drizzle/
  schema.ts                 profiles, mining_sessions, referrals, ledger, tasks
  migrations/               SQL migrations
```

## Run it

```bash
pnpm install
cp .env.example .env      # then fill in DATABASE_URL and JWT_SECRET
pnpm db:migrate           # create the tables
pnpm dev                  # API on :3001, Vite on :3000
```

Open http://localhost:3000.

Generate a secret with `openssl rand -base64 48`.

## Emission model

| Parameter | Value |
|---|---|
| Base rate | 0.0059 ELY / hour |
| Per 24h session | ~0.1416 ELY |
| Circle boost | +0.0025 ELY / hr per active member |
| Boost cap | 5 members → +0.0125 ELY / hr |
| Referral bonus | +0.10 ELY once, when an invitee claims their first session |
| Session length | 24 hours |

Rates lock at session start, so a boost earned today applies from the next session.

## Why the client cannot cheat

`shared/mining.ts → accrualFor()`:

```ts
hours  = (min(endsAt, now) - startedAt) / 3_600_000
amount = hours * (baseRate + boostRate)
```

The client sends only "start" or "claim" — never an amount, rate or timestamp.
A partial unique index (`mining_sessions_open_unique`) stops two simultaneous
starts, and per-claim markers (`claim_ref`, `bonus_ref`) make a double-tap credit
exactly once.

## Admin

Sign up on the site, then sign in at `/admin/login` with the same credentials.
The earliest-created account on a network with no admin is promoted to owner.
Add more admins with `ADMIN_EMAILS` (comma separated) in the environment.

## Tests

```bash
pnpm test
pnpm typecheck
```

## Deploy

Any Node 20+ host with Postgres. `pnpm build` then `pnpm start`.
Set `DATABASE_URL`, `JWT_SECRET`, `NODE_ENV=production`, `PORT`.
