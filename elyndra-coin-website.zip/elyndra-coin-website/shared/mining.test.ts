import { describe, expect, it } from "vitest";
import {
  BASE_RATE_PER_HOUR,
  BOOST_PER_MEMBER_PER_HOUR,
  MAX_BOOST_MEMBERS,
  MAX_BOOST_RATE,
  REFERRAL_BONUS,
  SESSION_MS,
  accrualFor,
  boostRateFor,
  formatDuration,
  round6,
  sessionProgress,
} from "./mining";

// The emission model is the whole product: if these numbers drift, the app is
// lying to its users about how slowly it mines. They are asserted against the
// spec's stated figures, not against whatever the code happens to produce.

describe("emission constants", () => {
  it("matches the spec's base rate and per-session yield", () => {
    expect(BASE_RATE_PER_HOUR).toBe(0.0059);
    // ~0.14 ELY for a full 24h session
    expect(round6(BASE_RATE_PER_HOUR * 24)).toBe(0.1416);
  });

  it("caps the circle boost at 5 members", () => {
    expect(MAX_BOOST_MEMBERS).toBe(5);
    expect(MAX_BOOST_RATE).toBe(0.0125);
    expect(round6(BOOST_PER_MEMBER_PER_HOUR * MAX_BOOST_MEMBERS)).toBe(MAX_BOOST_RATE);
  });

  it("pays a one-time 0.10 ELY referral bonus", () => {
    expect(REFERRAL_BONUS).toBe(0.1);
  });

  it("runs a session for exactly 24 hours", () => {
    expect(SESSION_MS).toBe(24 * 60 * 60 * 1000);
  });
});

describe("boostRateFor", () => {
  it("scales linearly with active members", () => {
    expect(boostRateFor(0)).toBe(0);
    expect(boostRateFor(1)).toBe(0.0025);
    expect(boostRateFor(3)).toBe(0.0075);
    expect(boostRateFor(5)).toBe(0.0125);
  });

  it("never exceeds the cap, however many members there are", () => {
    expect(boostRateFor(6)).toBe(MAX_BOOST_RATE);
    expect(boostRateFor(500)).toBe(MAX_BOOST_RATE);
  });

  it("treats nonsense input as zero rather than NaN", () => {
    expect(boostRateFor(-3)).toBe(0);
    expect(boostRateFor(2.9)).toBe(0.005); // floors to 2
  });
});

describe("accrualFor", () => {
  const start = new Date("2026-01-01T00:00:00Z");
  const end = new Date(start.getTime() + SESSION_MS);

  it("accrues base rate only, with no boost, over a full session", () => {
    const amount = accrualFor({
      startedAt: start,
      endsAt: end,
      now: end,
      baseRate: BASE_RATE_PER_HOUR,
      boostRate: 0,
    });
    expect(amount).toBe(0.1416);
  });

  it("adds the boost rate on top of the base rate", () => {
    const amount = accrualFor({
      startedAt: start,
      endsAt: end,
      now: end,
      baseRate: BASE_RATE_PER_HOUR,
      boostRate: MAX_BOOST_RATE,
    });
    // (0.0059 + 0.0125) * 24
    expect(amount).toBe(0.4416);
  });

  it("accrues proportionally part-way through a session", () => {
    const sixHoursIn = new Date(start.getTime() + 6 * 3_600_000);
    const amount = accrualFor({
      startedAt: start,
      endsAt: end,
      now: sixHoursIn,
      baseRate: BASE_RATE_PER_HOUR,
      boostRate: 0,
    });
    expect(amount).toBe(0.0354); // 0.0059 * 6
  });

  it("stops accruing at the session end, however long the app was closed", () => {
    const aWeekLater = new Date(start.getTime() + 7 * SESSION_MS);
    const amount = accrualFor({
      startedAt: start,
      endsAt: end,
      now: aWeekLater,
      baseRate: BASE_RATE_PER_HOUR,
      boostRate: 0,
    });
    // Exactly one session's worth — not seven.
    expect(amount).toBe(0.1416);
  });

  it("accrues nothing before the session starts", () => {
    const before = new Date(start.getTime() - 3_600_000);
    expect(
      accrualFor({
        startedAt: start,
        endsAt: end,
        now: before,
        baseRate: BASE_RATE_PER_HOUR,
        boostRate: 0,
      }),
    ).toBe(0);
  });

  it("accepts ISO strings as well as Dates", () => {
    expect(
      accrualFor({
        startedAt: start.toISOString(),
        endsAt: end.toISOString(),
        now: end.toISOString(),
        baseRate: BASE_RATE_PER_HOUR,
        boostRate: 0,
      }),
    ).toBe(0.1416);
  });

  it("returns 0 for unparseable input instead of NaN", () => {
    expect(
      accrualFor({
        startedAt: "not-a-date",
        endsAt: end,
        now: end,
        baseRate: BASE_RATE_PER_HOUR,
        boostRate: 0,
      }),
    ).toBe(0);
  });

  it("is monotonic: more elapsed time never means fewer coins", () => {
    let previous = -1;
    for (let h = 0; h <= 24; h += 2) {
      const amount = accrualFor({
        startedAt: start,
        endsAt: end,
        now: new Date(start.getTime() + h * 3_600_000),
        baseRate: BASE_RATE_PER_HOUR,
        boostRate: MAX_BOOST_RATE,
      });
      expect(amount).toBeGreaterThanOrEqual(previous);
      previous = amount;
    }
  });
});

describe("sessionProgress", () => {
  const start = new Date("2026-01-01T00:00:00Z");
  const end = new Date(start.getTime() + SESSION_MS);

  it("is 0 at the start, 0.5 halfway, 1 at the end", () => {
    expect(sessionProgress({ startedAt: start, endsAt: end, now: start })).toBe(0);
    expect(
      sessionProgress({ startedAt: start, endsAt: end, now: new Date(start.getTime() + SESSION_MS / 2) }),
    ).toBe(0.5);
    expect(sessionProgress({ startedAt: start, endsAt: end, now: end })).toBe(1);
  });

  it("clamps outside the session rather than going negative or past 1", () => {
    expect(
      sessionProgress({ startedAt: start, endsAt: end, now: new Date(start.getTime() - 1000) }),
    ).toBe(0);
    expect(
      sessionProgress({ startedAt: start, endsAt: end, now: new Date(end.getTime() + 1000) }),
    ).toBe(1);
  });
});

describe("formatting", () => {
  it("formats ELY to a fixed number of decimals", () => {
    expect(round6(0.14160000000000002)).toBe(0.1416);
    expect(round6(1 / 3)).toBe(0.333333);
  });

  it("formats durations for the countdown", () => {
    expect(formatDuration(0)).toBe("0s");
    expect(formatDuration(45_000)).toBe("45s");
    expect(formatDuration(90_000)).toBe("1m 30s");
    expect(formatDuration(3_600_000)).toBe("1h 00m");
    expect(formatDuration(23 * 3_600_000 + 59 * 60_000)).toBe("23h 59m");
  });

  it("never renders a negative duration", () => {
    expect(formatDuration(-5000)).toBe("0s");
  });
});
