// ── Elyndra mining model ─────────────────────────────────────────────────────
// Shared by the server (authoritative accrual) and the client (live counter).
// Pure functions only: no database, no clock of its own — every function takes
// the "now" it should reason about, so the same code is testable and the client
// can tick smoothly between server polls without ever being trusted.

/** Base emission, in ELY per hour. Deliberately Pi-slow. */
export const BASE_RATE_PER_HOUR = 0.0059;

/** Extra rate per active Security Circle member, in ELY per hour. */
export const BOOST_PER_MEMBER_PER_HOUR = 0.0025;

/** Security Circle members that count toward the boost. */
export const MAX_BOOST_MEMBERS = 5;

/** One mining session lasts exactly this long. */
export const SESSION_HOURS = 24;
export const SESSION_MS = SESSION_HOURS * 60 * 60 * 1000;

/** One-time credit to the referrer when a referee claims their first session. */
export const REFERRAL_BONUS = 0.1;

/** Ceiling of the circle boost: 5 × 0.0025. */
export const MAX_BOOST_RATE = 0.0125;

/** ELY is tracked to 6 decimal places — the smallest unit the ledger records. */
export function round6(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000;
}

/** Boost rate for a given number of active circle members, capped at 5. */
export function boostRateFor(activeMembers: number): number {
  const capped = Math.min(Math.max(Math.floor(activeMembers), 0), MAX_BOOST_MEMBERS);
  return round6(capped * BOOST_PER_MEMBER_PER_HOUR);
}

/**
 * Coins accrued by a session between `startedAt` and `min(endsAt, now)`.
 * This is the whole anti-cheat story: the amount is a function of timestamps
 * only, so a client cannot inflate it by staying open, and it keeps accruing
 * while the app is closed.
 */
export function accrualFor(input: {
  startedAt: Date | string | number;
  endsAt: Date | string | number;
  now: Date | string | number;
  baseRate: number;
  boostRate: number;
}): number {
  const start = new Date(input.startedAt).getTime();
  const end = new Date(input.endsAt).getTime();
  const now = new Date(input.now).getTime();
  if (!Number.isFinite(start) || !Number.isFinite(end) || !Number.isFinite(now)) return 0;
  const stop = Math.min(end, now);
  if (stop <= start) return 0;
  const hours = (stop - start) / 3_600_000;
  return round6(hours * (input.baseRate + input.boostRate));
}

/** Fraction of the session elapsed, clamped to 0…1. */
export function sessionProgress(input: {
  startedAt: Date | string | number;
  endsAt: Date | string | number;
  now: Date | string | number;
}): number {
  const start = new Date(input.startedAt).getTime();
  const end = new Date(input.endsAt).getTime();
  const now = new Date(input.now).getTime();
  const total = end - start;
  if (!Number.isFinite(total) || total <= 0) return 0;
  return Math.min(Math.max((now - start) / total, 0), 1);
}

export function formatEly(value: number, decimals = 4): string {
  if (!Number.isFinite(value)) return (0).toFixed(decimals);
  return value.toFixed(decimals);
}

export function formatDuration(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  if (m > 0) return `${m}m ${String(s).padStart(2, "0")}s`;
  return `${s}s`;
}

// ── Wire types (server → client) ─────────────────────────────────────────────

export interface MiningRates {
  base: number;
  boost: number;
  total: number;
  activeMembers: number;
  maxMembers: number;
}

export interface MiningSessionView {
  id: string;
  startedAt: string;
  endsAt: string;
  baseRate: number;
  boostRate: number;
  /** Coins accrued so far, as of `serverNow`. */
  accrued: number;
  claimed: boolean;
  remainingMs: number;
  progress: number;
}

export interface MiningProfileView {
  username: string;
  referralCode: string;
  balance: number;
  totalMined: number;
  createdAt: string;
}

export interface MiningStatus {
  profile: MiningProfileView;
  session: MiningSessionView | null;
  rates: MiningRates;
  team: { active: number; total: number };
  /** Set by an admin: the account can claim but cannot open a new session. */
  suspended: boolean;
  /** Admin banner for the mining screen, or null when there is none. */
  announcement: string | null;
  /** Server clock at the moment of the response — the client's time anchor. */
  serverNow: string;
}

export interface TeamMemberView {
  username: string;
  active: boolean;
  joinedAt: string;
}

export interface TeamView {
  referralCode: string;
  members: TeamMemberView[];
  activeMembers: number;
  maxMembers: number;
  boostRate: number;
  bonusPerReferral: number;
}

export type LedgerType = "mining" | "referral_bonus";

export interface LedgerEntryView {
  id: string;
  amount: number;
  type: LedgerType;
  note: string | null;
  createdAt: string;
}
