// ── Admin surface: settings model + wire types ────────────────────────────────
// Shared by the server (which owns the values) and the dashboard (which edits
// them). Pure functions only, so the parsing rules are testable without a DB.

import {
  BASE_RATE_PER_HOUR,
  BOOST_PER_MEMBER_PER_HOUR,
  MAX_BOOST_MEMBERS,
  REFERRAL_BONUS,
  SESSION_HOURS,
} from "./mining";

/**
 * Everything the admin can change from the browser. Each field maps to one row
 * in `site_settings`; a missing or unreadable row falls back to the default
 * below rather than breaking the app.
 */
export interface SiteSettings {
  /** Base emission, ELY per hour. */
  baseRatePerHour: number;
  /** Extra rate per active Security Circle member, ELY per hour. */
  boostPerMemberPerHour: number;
  /** How many active members count toward the boost. */
  maxBoostMembers: number;
  /** One-time credit to a referrer when a referee claims their first session. */
  referralBonus: number;
  /** Length of one mining session, in hours. */
  sessionHours: number;
  /** When on, starting and claiming are refused with `maintenanceMessage`. */
  maintenanceMode: boolean;
  maintenanceMessage: string;
  /** Shown as a banner on the mining screen. Empty means no banner. */
  announcement: string;
}

export const DEFAULT_SETTINGS: SiteSettings = {
  baseRatePerHour: BASE_RATE_PER_HOUR,
  boostPerMemberPerHour: BOOST_PER_MEMBER_PER_HOUR,
  maxBoostMembers: MAX_BOOST_MEMBERS,
  referralBonus: REFERRAL_BONUS,
  sessionHours: SESSION_HOURS,
  maintenanceMode: false,
  maintenanceMessage: "Elyndra is briefly offline for maintenance. Your session keeps accruing.",
  announcement: "",
};

/** Bounds that keep a typo in the dashboard from wrecking the economy. */
export const SETTING_LIMITS = {
  baseRatePerHour: { min: 0, max: 1 },
  boostPerMemberPerHour: { min: 0, max: 1 },
  maxBoostMembers: { min: 0, max: 50 },
  referralBonus: { min: 0, max: 100 },
  sessionHours: { min: 1, max: 168 },
} as const;

function num(raw: string | undefined, fallback: number, min: number, max: number): number {
  if (raw === undefined || raw.trim() === "") return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(n, min), max);
}

function bool(raw: string | undefined, fallback: boolean): boolean {
  if (raw === undefined) return fallback;
  return raw === "true" || raw === "1";
}

/**
 * Turn raw key/value rows into a complete, in-range settings object. Unknown
 * keys are ignored and bad values fall back — the dashboard can never leave the
 * app in a state it cannot read.
 */
export function parseSettings(rows: { key: string; value: string }[]): SiteSettings {
  const map = new Map(rows.map((r) => [r.key, r.value]));
  const L = SETTING_LIMITS;
  return {
    baseRatePerHour: num(map.get("base_rate_per_hour"), DEFAULT_SETTINGS.baseRatePerHour, L.baseRatePerHour.min, L.baseRatePerHour.max),
    boostPerMemberPerHour: num(map.get("boost_per_member_per_hour"), DEFAULT_SETTINGS.boostPerMemberPerHour, L.boostPerMemberPerHour.min, L.boostPerMemberPerHour.max),
    maxBoostMembers: Math.round(num(map.get("max_boost_members"), DEFAULT_SETTINGS.maxBoostMembers, L.maxBoostMembers.min, L.maxBoostMembers.max)),
    referralBonus: num(map.get("referral_bonus"), DEFAULT_SETTINGS.referralBonus, L.referralBonus.min, L.referralBonus.max),
    sessionHours: num(map.get("session_hours"), DEFAULT_SETTINGS.sessionHours, L.sessionHours.min, L.sessionHours.max),
    maintenanceMode: bool(map.get("maintenance_mode"), DEFAULT_SETTINGS.maintenanceMode),
    maintenanceMessage: map.get("maintenance_message") ?? DEFAULT_SETTINGS.maintenanceMessage,
    announcement: map.get("announcement") ?? DEFAULT_SETTINGS.announcement,
  };
}

/** Flatten settings back to the rows that store them. */
export function settingsToRows(s: SiteSettings): { key: string; value: string }[] {
  return [
    { key: "base_rate_per_hour", value: String(s.baseRatePerHour) },
    { key: "boost_per_member_per_hour", value: String(s.boostPerMemberPerHour) },
    { key: "max_boost_members", value: String(s.maxBoostMembers) },
    { key: "referral_bonus", value: String(s.referralBonus) },
    { key: "session_hours", value: String(s.sessionHours) },
    { key: "maintenance_mode", value: s.maintenanceMode ? "true" : "false" },
    { key: "maintenance_message", value: s.maintenanceMessage },
    { key: "announcement", value: s.announcement },
  ];
}

// ── Wire types ────────────────────────────────────────────────────────────────

export type TaskKind = "task" | "announcement";

export interface AdminTaskView {
  id: string;
  title: string;
  body: string;
  kind: TaskKind;
  active: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminStats {
  totalUsers: number;
  newUsersToday: number;
  activeSessions: number;
  totalMined: number;
  totalBalance: number;
  suspendedUsers: number;
  activeTasks: number;
}

export interface AdminUserRow {
  userId: string;
  email: string;
  username: string;
  balance: number;
  totalMined: number;
  suspended: boolean;
  role: string;
  circleActive: number;
  circleTotal: number;
  createdAt: string;
}
