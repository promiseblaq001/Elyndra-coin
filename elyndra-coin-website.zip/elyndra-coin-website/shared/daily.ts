// ── Daily task model ──────────────────────────────────────────────────────────
// Shared by the server (which decides what "today" is and pays the reward) and
// the client (which shows progress). Pure functions only.

/** The UTC calendar day a completion belongs to, as `YYYY-MM-DD`. */
export function dayKey(at: Date | string | number = new Date()): string {
  const d = new Date(at);
  if (!Number.isFinite(d.getTime())) return "1970-01-01";
  return d.toISOString().slice(0, 10);
}

/** Milliseconds until the next UTC midnight — when the daily task resets. */
export function msUntilReset(now: Date | string | number = new Date()): number {
  const d = new Date(now);
  const next = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + 1, 0, 0, 0, 0);
  return Math.max(0, next - d.getTime());
}

export interface DailyTaskView {
  id: string;
  title: string;
  body: string;
  reward: number;
  /** True when this user has already completed it today. */
  done: boolean;
  /** When it was completed today, if it was. */
  completedAt: string | null;
}

export interface DailyProgress {
  /** UTC day these figures describe. */
  day: string;
  tasks: DailyTaskView[];
  completedCount: number;
  totalCount: number;
  /** ELY earned from daily tasks today. */
  earnedToday: number;
  /** Consecutive days with at least one completion, ending today or yesterday. */
  streak: number;
  /** Milliseconds until the tasks reset (next UTC midnight). */
  resetsInMs: number;
}
